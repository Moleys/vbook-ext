function execute() {
    return Response.success([
        {title: "全部", input:  "https://520banxia.com/weekvisit_0_0_", script: "gen.js"},
        {title: "玄幻魔法", input:  "https://520banxia.com/weekvisit_1_0_", script: "gen.js"},
        {title: "修真武俠", input:  "https://520banxia.com/weekvisit_2_0_", script: "gen.js"},
        {title: "現代都市", input:  "https://520banxia.com/weekvisit_3_0_", script: "gen.js"},
        {title: "歷史軍事", input:  "https://520banxia.com/weekvisit_4_0_", script: "gen.js"},
        {title: "遊戲競技", input:  "https://520banxia.com/weekvisit_5_0_", script: "gen.js"},
        {title: "科幻小說", input:  "https://520banxia.com/weekvisit_6_0_", script: "gen.js"},
        {title: "恐怖靈異", input:  "https://520banxia.com/weekvisit_7_0_", script: "gen.js"},
        {title: "言情小說", input:  "https://520banxia.com/weekvisit_8_0_", script: "gen.js"},
        {title: "其他小說", input:  "https://520banxia.com/weekvisit_9_0_", script: "gen.js"}

    ]);
}