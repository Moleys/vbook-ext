function execute() {
    return Response.success([
        {title: "都市情感", input:  "http://www.powanjuan.cc/dsyq/", script: "zen.js"},
        {title: "青春言情", input:  "http://www.powanjuan.cc/qcyq/", script: "zen.js"},
        {title: "耽美小说", input:  "http://www.powanjuan.cc/dmtr/", script: "zen.js"},
        {title: "同人小说", input:  "http://www.powanjuan.cc/tongren/", script: "zen.js"},
        {title: "玄幻奇幻", input:  "http://www.powanjuan.cc/wxxz/", script: "zen.js"},
        {title: "武侠修真", input:  "http://www.powanjuan.cc/wxxz2/", script: "zen.js"},
        {title: "穿越架空", input:  "http://www.powanjuan.cc/cyjk/", script: "zen.js"},
        {title: "科幻魔法", input:  "http://www.powanjuan.cc/khjj/", script: "zen.js"},
        {title: "游戏竞技", input:  "http://www.powanjuan.cc/yxjj/", script: "zen.js"},
        {title: "鬼话悬疑", input:  "http://www.powanjuan.cc/ghxy/", script: "zen.js"},
        {title: "军事历史", input:  "http://www.powanjuan.cc/jsls/", script: "zen.js"},
        {title: "乡土风情", input:  "http://www.powanjuan.cc/xtfq/", script: "zen.js"},
        {title: "总排行榜", input:  "http://www.powanjuan.cc/sort/", script: "zen.js"}
    ]);
}