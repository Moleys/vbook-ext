function execute() {
    return Response.success([
        {title: "全部分类", input: "http://www.yuedsk.com/book/topallvisit/0", script: "gen2.js"},
        {title: "玄幻魔法", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=1&page=", script: "gen.js"},    
        {title: "武侠修真", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=2&page=", script: "gen.js"},    
        {title: "都市言情", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=3&page=", script: "gen.js"},    
        {title: "历史军事", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=4&page=", script: "gen.js"},    
        {title: "侦探推理", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=5&page=", script: "gen.js"},    
        {title: "网游动漫", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=6&page=", script: "gen.js"},    
        {title: "科幻小说", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=7&page=", script: "gen.js"},    
        {title: "恐怖灵异", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=8&page=", script: "gen.js"},    
        {title: "言情小说", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=9&page=", script: "gen.js"},    
        {title: "其他类型", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=10&page=", script: "gen.js"},    
        {title: "经部", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=11&page=", script: "gen.js"},    
        {title: "史书", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=12&page=", script: "gen.js"},    
        {title: "子部", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=13&page=", script: "gen.js"},    
        {title: "集部", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=14&page=", script: "gen.js"},    
        {title: "四库之外", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=15&page=", script: "gen.js"},    
        {title: "古典书籍", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=16&page=", script: "gen.js"},    
        {title: "诗歌", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=17&page=", script: "gen.js"},    
        {title: "宋词", input: "http://www.yuedsk.com/modules/article/toplist.php?order=allvisit&sortid=18&page=", script: "gen.js"},  

    ]);
}