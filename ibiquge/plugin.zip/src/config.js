let base_url = 'https://www.nettruyenmax.com';
if (typeof config_url !== "undefined") {
    base_url = config_url
}