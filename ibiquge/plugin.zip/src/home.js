function execute() {
    return Response.success([
        {title: "首页", input: "http://www.ibiquge.net/", script: "gen.js"}

    ]);
}