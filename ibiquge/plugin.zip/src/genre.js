function execute() {
    return Response.success([
        {title: "玄幻奇幻", input:  "https://www.ibiquzw.com/xuanhuanxiaoshuo/1_", script: "zen.js"},
        {title: "修真仙侠", input:  "https://www.ibiquzw.com/xiuzhenxiaoshuo/2_", script: "zen.js"},
        {title: "都市青春", input:  "https://www.ibiquzw.com/dushixiaoshuo/3_", script: "zen.js"},
        {title: "历史军事", input:  "https://www.ibiquzw.com/lishixiaoshuo/4_", script: "zen.js"},
        {title: "网游竞技", input:  "https://www.ibiquzw.com/wangyouxiaoshuo/5_", script: "zen.js"},
        {title: "科幻灵异", input:  "https://www.ibiquzw.com/kehuanxiaoshuo/6_", script: "zen.js"},
        {title: "其它小说", input:  "https://www.ibiquzw.com/qitaxiaoshuo/7_", script: "zen.js"},
        {title: "全本小说", input:  "https://www.ibiquzw.com/wanben/1_", script: "zen.js"},
    ]);
}