function execute() {
    return Response.success([
        {title: "[周榜]玄幻奇幻", input:  "http://www.min-yuan.com/sort/1/week/", script: "zen.js"},
        {title: "[周榜]武侠仙侠", input:  "http://www.min-yuan.com/sort/2/week/", script: "zen.js"},
        {title: "[周榜]都市言情", input:  "http://www.min-yuan.com/sort/3/week/", script: "zen.js"},
        {title: "[周榜]历史军事", input:  "http://www.min-yuan.com/sort/4/week/", script: "zen.js"},
        {title: "[周榜]科幻灵异", input:  "http://www.min-yuan.com/sort/5/week/", script: "zen.js"},
        {title: "[周榜]网游竞技", input:  "http://www.min-yuan.com/sort/6/week/", script: "zen.js"},
        {title: "[周榜]女生频道", input:  "http://www.min-yuan.com/sort/7/week/", script: "zen.js"},
        {title: "[月榜]玄幻奇幻", input:  "http://www.min-yuan.com/sort/1/month/", script: "zen.js"},
        {title: "[月榜]武侠仙侠", input:  "http://www.min-yuan.com/sort/2/month/", script: "zen.js"},
        {title: "[月榜]都市言情", input:  "http://www.min-yuan.com/sort/3/month/", script: "zen.js"},
        {title: "[月榜]历史军事", input:  "http://www.min-yuan.com/sort/4/month/", script: "zen.js"},
        {title: "[月榜]科幻灵异", input:  "http://www.min-yuan.com/sort/5/month/", script: "zen.js"},
        {title: "[月榜]网游竞技", input:  "http://www.min-yuan.com/sort/6/month/", script: "zen.js"},
        {title: "[月榜]女生频道", input:  "http://www.min-yuan.com/sort/7/month/", script: "zen.js"}
    ]);
}