function execute() {
    return Response.success([
    {"title":"都市脑洞", input: "https://api3-normal-lf.fqnovel.com/reading/bookapi/new_category/landing/v/?word_number=0&book_status=2&category_id=262&offset={page}&genre_type=0&limit=24&sort_by=24&source=front_category&query_gender=1&iid=1099935039893805&aid=1967&app_name=novelapp&version_code=287", script: "gen2.js" },
    {"title":"玄幻脑洞", input: "https://api3-normal-lf.fqnovel.com/reading/bookapi/new_category/landing/v/?word_number=0&book_status=2&category_id=257&offset={page}&genre_type=0&limit=24&sort_by=24&source=front_category&query_gender=1&iid=1099935039893805&aid=1967&app_name=novelapp&version_code=287", script: "gen2.js" },
 {"title":"科幻", input: "https://api3-normal-lf.fqnovel.com/reading/bookapi/new_category/landing/v/?word_number=0&book_status=2&category_id=8&offset={page}&genre_type=0&limit=24&sort_by=24&source=front_category&query_gender=1&iid=1099935039893805&aid=1967&app_name=novelapp&version_code=287", script: "gen2.js" }
  
    ]);
}