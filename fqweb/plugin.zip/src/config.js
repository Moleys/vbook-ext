let config_host = "http://localhost:9999";
if (typeof host !== "undefined") {
    config_host = host
}