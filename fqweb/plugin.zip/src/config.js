let config_host = "https://fq.beitai.vip"
let config_host2 = "https://fq.beitai.vip";
if (typeof host !== "undefined") {
    config_host2 = host
}