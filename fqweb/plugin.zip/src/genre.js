function execute() {
    return Response.success([{
            title: "男-都市",
            input: "&category_id=1&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-玄幻",
            input: "&category_id=7&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-灵异",
            input: "&category_id=100&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-战神",
            input: "&category_id=27&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-神医",
            input: "&category_id=26&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-悬疑",
            input: "&category_id=10&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-悬疑灵异",
            input: "&category_id=751&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-穿越",
            input: "&category_id=37&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-重生",
            input: "&category_id=36&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-都市脑洞",
            input: "&category_id=262&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-都市修真",
            input: "&category_id=124&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-系统",
            input: "&category_id=19&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-赘婿",
            input: "&category_id=25&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-神豪",
            input: "&category_id=20&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-都市日常",
            input: "&category_id=261&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-推理",
            input: "&category_id=61&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-架空",
            input: "&category_id=452&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-科幻",
            input: "&category_id=8&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-东方玄幻",
            input: "&category_id=511&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-武侠",
            input: "&category_id=16&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-特种兵",
            input: "&category_id=375&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-盗墓",
            input: "&category_id=81&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-剑道",
            input: "&category_id=80&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-空间",
            input: "&category_id=44&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-无敌",
            input: "&category_id=384&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-三国",
            input: "&category_id=67&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-外卖",
            input: "&category_id=75&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-奶爸",
            input: "&category_id=42&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-乡村",
            input: "&category_id=11&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-同人",
            input: "&category_id=538&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-末世",
            input: "&category_id=68&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-都市异能",
            input: "&category_id=516&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-海岛",
            input: "&category_id=40&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-游戏体育",
            input: "&category_id=746&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-二次元",
            input: "&category_id=39&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-洪荒",
            input: "&category_id=66&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-求生",
            input: "&category_id=379&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-体育",
            input: "&category_id=15&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-大唐",
            input: "&category_id=73&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-明朝",
            input: "&category_id=126&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-扮猪吃虎",
            input: "&category_id=93&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-历史脑洞",
            input: "&category_id=272&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-星际",
            input: "&category_id=77&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-校花",
            input: "&category_id=385&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-直播",
            input: "&category_id=69&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-年代",
            input: "&category_id=79&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-家庭",
            input: "&category_id=125&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-宠物",
            input: "&category_id=74&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-网游",
            input: "&category_id=372&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-衍生同人",
            input: "&category_id=718&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-娱乐圈",
            input: "&category_id=43&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-开局",
            input: "&category_id=453&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-职场",
            input: "&category_id=127&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-大小姐",
            input: "&category_id=519&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-大秦",
            input: "&category_id=377&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-单女主",
            input: "&category_id=389&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-抗战谍战",
            input: "&category_id=504&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-聊天群",
            input: "&category_id=381&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-美食",
            input: "&category_id=78&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-末日求生",
            input: "&category_id=515&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-搞笑轻松",
            input: "&category_id=778&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-悬疑脑洞",
            input: "&category_id=539&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-修仙",
            input: "&category_id=517&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-反派",
            input: "&category_id=369&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-腹黑",
            input: "&category_id=92&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-电竞",
            input: "&category_id=508&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-学霸",
            input: "&category_id=82&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-影视小说",
            input: "&category_id=45&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-都市青春",
            input: "&category_id=396&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-异世大陆",
            input: "&category_id=512&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-特工",
            input: "&category_id=518&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-官场",
            input: "&category_id=788&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-无限流",
            input: "&category_id=70&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-游戏主播",
            input: "&category_id=509&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-大佬",
            input: "&category_id=520&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-女帝",
            input: "&category_id=378&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-灵气复苏",
            input: "&category_id=514&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-神探",
            input: "&category_id=506&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-武将",
            input: "&category_id=497&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-火影",
            input: "&category_id=368&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-无女主",
            input: "&category_id=391&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-龙珠",
            input: "&category_id=376&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-宋朝",
            input: "&category_id=501&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-钓鱼",
            input: "&category_id=493&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-皇帝",
            input: "&category_id=498&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-穿书",
            input: "&category_id=382&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-囤物资",
            input: "&category_id=494&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-漫威",
            input: "&category_id=374&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-生活",
            input: "&category_id=48&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-高武世界",
            input: "&category_id=513&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-海贼",
            input: "&category_id=370&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-奥特同人",
            input: "&category_id=367&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-战争",
            input: "&category_id=97&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-神奇宝贝",
            input: "&category_id=371&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-断层",
            input: "&category_id=500&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-惊悚",
            input: "&category_id=322&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-宫廷侯爵",
            input: "&category_id=502&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-九叔",
            input: "&category_id=383&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-综漫",
            input: "&category_id=465&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-文学小说",
            input: "&category_id=47&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-谍战",
            input: "&category_id=507&gender=1",
            script: "gen3.js"
        },
        {
            title: "男-成功励志",
            input: "&category_id=56&gender=1",
            script: "gen3.js"
        },
        {
            title: "女-现代言情",
            input: "&category_id=3&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-豪门总裁",
            input: "&category_id=29&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-古代言情",
            input: "&category_id=5&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-宠妻",
            input: "&category_id=30&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-甜宠",
            input: "&category_id=96&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-穿越",
            input: "&category_id=37&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-宫斗宅斗",
            input: "&category_id=246&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-霸总",
            input: "&category_id=748&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-萌宝",
            input: "&category_id=28&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-王妃",
            input: "&category_id=85&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-重生",
            input: "&category_id=36&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-HE",
            input: "&category_id=484&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-幻想言情",
            input: "&category_id=32&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-都市生活",
            input: "&category_id=2&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-腹黑",
            input: "&category_id=92&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-豪门世家",
            input: "&category_id=473&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-种田",
            input: "&category_id=23&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-豪门爽文",
            input: "&category_id=745&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-现言脑洞",
            input: "&category_id=267&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-玄幻言情",
            input: "&category_id=248&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-嫡女",
            input: "&category_id=88&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-职场婚恋",
            input: "&category_id=750&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-医术",
            input: "&category_id=247&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-打脸",
            input: "&category_id=522&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-空间",
            input: "&category_id=44&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-女强",
            input: "&category_id=86&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-日久生情",
            input: "&category_id=474&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-娱乐圈",
            input: "&category_id=43&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-家庭",
            input: "&category_id=125&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-团宠",
            input: "&category_id=94&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-今穿古",
            input: "&category_id=463&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-皇后",
            input: "&category_id=84&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-灵异",
            input: "&category_id=100&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-天才",
            input: "&category_id=90&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-闪婚",
            input: "&category_id=466&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-校园",
            input: "&category_id=4&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-系统",
            input: "&category_id=19&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-公主",
            input: "&category_id=83&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-独宠",
            input: "&category_id=460&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-马甲",
            input: "&category_id=266&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-虐文",
            input: "&category_id=95&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-婚恋",
            input: "&category_id=34&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-契约婚姻",
            input: "&category_id=471&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-护短",
            input: "&category_id=458&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-年代",
            input: "&category_id=79&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-悬疑",
            input: "&category_id=10&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-一见钟情",
            input: "&category_id=477&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-悬疑恋爱",
            input: "&category_id=747&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-古言脑洞",
            input: "&category_id=253&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-前世今生",
            input: "&category_id=523&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-青梅竹马",
            input: "&category_id=387&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-大佬",
            input: "&category_id=520&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-毒医",
            input: "&category_id=491&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-快穿",
            input: "&category_id=24&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-带球跑",
            input: "&category_id=479&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-学霸",
            input: "&category_id=82&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-影视小说",
            input: "&category_id=45&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-冰山",
            input: "&category_id=468&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-病娇",
            input: "&category_id=380&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-精灵",
            input: "&category_id=89&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-大小姐",
            input: "&category_id=519&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-扮猪吃虎",
            input: "&category_id=93&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-明星",
            input: "&category_id=486&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-相爱相杀",
            input: "&category_id=483&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-无敌",
            input: "&category_id=384&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-乡村",
            input: "&category_id=11&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-情有独钟",
            input: "&category_id=456&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-推理",
            input: "&category_id=61&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-替身",
            input: "&category_id=470&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-美食",
            input: "&category_id=78&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-强强",
            input: "&category_id=478&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-破镜重圆",
            input: "&category_id=475&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-穿书",
            input: "&category_id=382&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-反派",
            input: "&category_id=369&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-将军",
            input: "&category_id=492&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-皇叔",
            input: "&category_id=87&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-异世穿越",
            input: "&category_id=464&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-医生",
            input: "&category_id=487&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-无CP",
            input: "&category_id=392&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-二次元",
            input: "&category_id=39&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-兽世",
            input: "&category_id=72&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-民国",
            input: "&category_id=390&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-逃婚",
            input: "&category_id=480&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-双面",
            input: "&category_id=469&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-双重生",
            input: "&category_id=524&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-直播",
            input: "&category_id=69&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-女扮男装",
            input: "&category_id=388&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-搞笑轻松",
            input: "&category_id=778&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-职场",
            input: "&category_id=127&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-盗墓",
            input: "&category_id=81&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-古灵精怪",
            input: "&category_id=459&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-末世",
            input: "&category_id=68&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-古穿今",
            input: "&category_id=462&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-暗恋",
            input: "&category_id=482&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-双向奔赴",
            input: "&category_id=476&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-律师",
            input: "&category_id=488&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-隐婚",
            input: "&category_id=467&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-天作之合",
            input: "&category_id=455&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-现言萌宝",
            input: "&category_id=489&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-清穿",
            input: "&category_id=76&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-双洁",
            input: "&category_id=702&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-可盐可甜",
            input: "&category_id=454&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-星际",
            input: "&category_id=77&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-作精",
            input: "&category_id=521&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-厨娘",
            input: "&category_id=490&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-双男主",
            input: "&category_id=275&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-同人",
            input: "&category_id=538&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-悬疑脑洞",
            input: "&category_id=539&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-武侠",
            input: "&category_id=16&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-现言复仇",
            input: "&category_id=268&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-游戏体育",
            input: "&category_id=746&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-科幻",
            input: "&category_id=8&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-衍生同人",
            input: "&category_id=718&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-囤物资",
            input: "&category_id=494&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-都市日常",
            input: "&category_id=261&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-群穿",
            input: "&category_id=461&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-电竞",
            input: "&category_id=508&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-游戏主播",
            input: "&category_id=509&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-职场商战",
            input: "&category_id=485&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-双女主",
            input: "&category_id=704&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-文学小说",
            input: "&category_id=47&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-综漫",
            input: "&category_id=465&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-四合院",
            input: "&category_id=495&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-文化历史",
            input: "&category_id=62&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-生活",
            input: "&category_id=48&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-战争",
            input: "&category_id=97&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-逃荒",
            input: "&category_id=557&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-成功励志",
            input: "&category_id=56&gender=0",
            script: "gen3.js"
        },
        {
            title: "女-抗战谍战",
            input: "&category_id=504&gender=0",
            script: "gen3.js"
        },
        {
            title: "出版-文学小说",
            input: "&category_id=47&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-现代言情",
            input: "&category_id=3&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-现实小说",
            input: "&category_id=400&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-经济管理",
            input: "&category_id=53&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-社会科学",
            input: "&category_id=50&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-诗歌散文",
            input: "&category_id=46&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-文化历史",
            input: "&category_id=62&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-成功励志",
            input: "&category_id=56&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-历史传记",
            input: "&category_id=404&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-人文社科",
            input: "&category_id=405&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-当代文学",
            input: "&category_id=399&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-经典国学",
            input: "&category_id=423&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-文学理论",
            input: "&category_id=401&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-个人成长",
            input: "&category_id=410&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-古代言情",
            input: "&category_id=5&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-生活",
            input: "&category_id=48&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-腹黑",
            input: "&category_id=92&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-人际交往",
            input: "&category_id=412&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-中国名著",
            input: "&category_id=98&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-中国历史",
            input: "&category_id=402&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-宫斗宅斗",
            input: "&category_id=246&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-都市",
            input: "&category_id=1&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-都市日常",
            input: "&category_id=261&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-都市生活",
            input: "&category_id=2&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-历史",
            input: "&category_id=12&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-玄幻言情",
            input: "&category_id=248&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-精灵",
            input: "&category_id=89&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-家庭",
            input: "&category_id=125&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-王妃",
            input: "&category_id=85&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-亲子家教",
            input: "&category_id=415&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-职场",
            input: "&category_id=127&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-职场婚恋",
            input: "&category_id=750&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-豪门总裁",
            input: "&category_id=29&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-影视小说",
            input: "&category_id=45&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-甜宠",
            input: "&category_id=96&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-宠妻",
            input: "&category_id=30&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-心理学",
            input: "&category_id=407&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-玄幻",
            input: "&category_id=7&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-悬疑",
            input: "&category_id=10&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-推理",
            input: "&category_id=61&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-文化艺术",
            input: "&category_id=413&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-幻想言情",
            input: "&category_id=32&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-思维智商",
            input: "&category_id=411&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-公主",
            input: "&category_id=83&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-保健养生",
            input: "&category_id=416&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-穿越",
            input: "&category_id=37&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-外国文学",
            input: "&category_id=397&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-人物传记",
            input: "&category_id=409&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-世界历史",
            input: "&category_id=403&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-两性",
            input: "&category_id=274&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-武侠",
            input: "&category_id=16&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-校园",
            input: "&category_id=4&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-外国名著",
            input: "&category_id=99&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-美食休闲",
            input: "&category_id=419&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-政治军事",
            input: "&category_id=408&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-哲学宗教",
            input: "&category_id=406&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-风水占卜",
            input: "&category_id=421&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-国学",
            input: "&category_id=116&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-科技",
            input: "&category_id=52&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-娱乐圈",
            input: "&category_id=43&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-法律",
            input: "&category_id=142&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-教育",
            input: "&category_id=54&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-成人教育",
            input: "&category_id=722&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-古代",
            input: "&category_id=273&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-种田",
            input: "&category_id=23&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-现言脑洞",
            input: "&category_id=267&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-战争",
            input: "&category_id=97&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-天才",
            input: "&category_id=90&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-灵异",
            input: "&category_id=100&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-家居旅游",
            input: "&category_id=420&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-重生",
            input: "&category_id=36&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-青梅竹马",
            input: "&category_id=387&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-科幻",
            input: "&category_id=8&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-直播",
            input: "&category_id=69&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-悬疑灵异",
            input: "&category_id=751&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-古言脑洞",
            input: "&category_id=253&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-古代文学",
            input: "&category_id=398&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-民国",
            input: "&category_id=390&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-盗墓",
            input: "&category_id=81&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-都市脑洞",
            input: "&category_id=262&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-豪门爽文",
            input: "&category_id=745&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-官场",
            input: "&category_id=788&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-霸总",
            input: "&category_id=748&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-年代",
            input: "&category_id=79&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-学霸",
            input: "&category_id=82&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-明朝",
            input: "&category_id=126&genre_type=160",
            script: "gen3.js"
        },
        {
            title: "出版-时尚美妆",
            input: "&category_id=418&genre_type=160",
            script: "gen3.js"
        }
    ]);
}