load('config.js');
function execute() {
  return Response.success([
    { title: '小说首页', input: 'https://www.shuhaige.net', script: 'gen.js' },

  ]);
}
