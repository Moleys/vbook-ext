let BASE_URL = 'https://www.shuhaige.net';

try {
  if (CONFIG_URL) BASE_URL = CONFIG_URL;
} catch (e) {}