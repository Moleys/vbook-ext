function execute() {
    return Response.success([
        {title: "玄幻", input:  "https://www.novel543.com/bookstack/xuanhuan/", script: "zen.js"},
        {title: "修真", input:  "https://www.novel543.com/bookstack/xiuzhen/", script: "zen.js"},
        {title: "都市", input:  "https://www.novel543.com/bookstack/dushi/", script: "zen.js"},
        {title: "歷史", input:  "https://www.novel543.com/bookstack/lishi/", script: "zen.js"},
        {title: "網游", input:  "https://www.novel543.com/bookstack/wangyou/", script: "zen.js"},
        {title: "科幻", input:  "https://www.novel543.com/bookstack/kehuan/", script: "zen.js"},
        {title: "女頻", input:  "https://www.novel543.com/bookstack/nvpin/", script: "zen.js"},
        {title: "靈異", input:  "https://www.novel543.com/bookstack/lingyi/", script: "zen.js"},
        {title: "同人", input:  "https://www.novel543.com/bookstack/tongren/", script: "zen.js"},
        {title: "軍事", input:  "https://www.novel543.com/bookstack/junshi/", script: "zen.js"},
        {title: "懸疑", input:  "https://www.novel543.com/bookstack/xuanyi/", script: "zen.js"},
        {title: "穿越", input:  "https://www.novel543.com/bookstack/chuanyue/", script: "zen.js"},
        {title: "其他", input:  "https://www.novel543.com/bookstack/other/", script: "zen.js"}

    ]);
}