function execute() {
    return Response.success([
        {title: "首页", input: "https://www.novel543.com/", script: "gen.js"}

    ]);
}