function execute() {
    return Response.success([
        { title: "玄幻奇幻", input: "https://www.31bz.net/xuanhuan/", script: "gen.js" },
        { title: "武侠修真", input: "https://www.31bz.net/xiuzhen/", script: "gen.js" },
        { title: "历史军事", input: "https://www.31bz.net/lishi/", script: "gen.js" },
        { title: "游戏竞技", input: "https://www.31bz.net/wangyou/", script: "gen.js" },
        { title: "都市言情", input: "https://www.31bz.net/dushi/", script: "gen.js" },
        { title: "科幻灵异", input: "https://www.31bz.net/kehuan/", script: "gen.js" },
        { title: "女生频道", input: "https://www.31bz.net/nvpin/", script: "gen.js" },
        { title: "排行榜", input: "https://www.31bz.net/paihangbang/", script: "gen.js" }

    ]);
}