function execute() {
    return Response.success([
       {title: "首页", input: "https://www.soshuw.com/", script: "gen.js"},
        {title: "玄幻", input:  "https://www.soshuw.com/xuanhuan/", script: "gen.js"},
        {title: "武侠", input:  "https://www.soshuw.com/wuxia/", script: "gen.js"},
        {title: "科幻", input:  "https://www.soshuw.com/kehuan/", script: "gen.js"},
        {title: "历史", input:  "https://www.soshuw.com/lishi/", script: "gen.js"},
        {title: "游戏", input:  "https://www.soshuw.com/youxi/", script: "gen.js"},
        {title: "灵异", input:  "https://www.soshuw.com/lingyi/", script: "gen.js"},
        {title: "都市", input:  "https://www.soshuw.com/dushi/", script: "gen.js"},
        {title: "校园", input:  "https://www.soshuw.com/xiaoyuan/", script: "gen.js"},
        {title: "婚恋", input:  "https://www.soshuw.com/hunlian/", script: "gen.js"},
        {title: "总裁", input:  "https://www.soshuw.com/zongcai/", script: "gen.js"},
        {title: "穿越", input:  "https://www.soshuw.com/chuanyue/", script: "gen.js"},
        {title: "同人", input:  "https://www.soshuw.com/tongren/", script: "gen.js"},
        {title: "新书", input:  "https://www.soshuw.com/xinshu/", script: "gen.js"}

    ]);
}