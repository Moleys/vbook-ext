function execute() {
    return Response.success([
        {title: "穿越小说", input:  "http://www.ijjxs.com/txt/chuanyue/", script: "gen.js"},
        {title: "重生小说", input:  "http://www.ijjxs.com/txt/chongshengxiaoshuo/", script: "gen.js"},
        {title: "历史架空", input:  "http://www.ijjxs.com/txt/lsjs/", script: "gen.js"},
        {title: "现代言情", input:  "http://www.ijjxs.com/txt/young/", script: "gen.js"},
        {title: "总裁", input:  "http://www.ijjxs.com/txt/qinggan/", script: "gen.js"},
        {title: "仙侠", input:  "http://www.ijjxs.com/txt/wuxia/", script: "gen.js"},
        {title: "同人", input:  "http://www.ijjxs.com/txt/tongrenxiaoshuo/", script: "gen.js"},
        {title: "网游", input:  "http://www.ijjxs.com/txt/juben/", script: "gen.js"},
        {title: "耽于纯美", input:  "http://www.ijjxs.com/txt/dmtr/", script: "gen.js"},
        {title: "玄幻小说", input:  "http://www.ijjxs.com/txt/xuanhuan/", script: "gen.js"},
        {title: "都市异能", input:  "http://www.ijjxs.com/txt/dushi/", script: "gen.js"},
        {title: "历史军事", input:  "http://www.ijjxs.com/txt/tiexue/", script: "gen.js"},
        {title: "惊悚悬疑", input:  "http://www.ijjxs.com/txt/kongbu/", script: "gen.js"},

    ]);
}