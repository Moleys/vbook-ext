function execute(url) {
    url = url.replace('m.twbook.cc', 'www.twbook.cc');
    let response = fetch(url);
    if (response.ok) {

        let doc = response.html();
        // let coverImg = doc.select(".pt-bookdetail img").first().attr("src");

        return Response.success({
            name: "an",
            cover: "https://i1.twbook.cc/thumb/120x160/20220331/100712169894.jpg",
            // author: doc.select(".size12 p a").get(1).text().replace(/作\s*者：/g, ""),
            // // description: doc.select(".pt-book-intro").text(),
            // // detail: doc.select(".size12").get(2).text(),
            author: "a",
            description: "b",
            detail: "c",

            host: "http://www.twbook.cc"
        });
    }
    return null;
}