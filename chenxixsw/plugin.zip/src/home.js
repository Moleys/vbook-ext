function execute() {
    return Response.success([
        {title: "首页", input: "https://www.chenxixsw.com/", script: "gen.js"},
        {title: "玄幻奇幻", input: "https://www.chenxixsw.com/xhqh/", script: "gen.js"},
        {title: "仙侠武侠", input: "https://www.chenxixsw.com/xxwx/", script: "gen.js"},
        {title: "都市言情", input: "https://www.chenxixsw.com/dsyq/", script: "gen.js"},
        {title: "灵异科幻", input: "https://www.chenxixsw.com/khly/", script: "gen.js"},
        {title: "历史军事", input: "https://www.chenxixsw.com/jsls/", script: "gen.js"},
        {title: "网游动漫", input: "https://www.chenxixsw.com/wydm/", script: "gen.js"},
        {title: "青春言情", input: "https://www.chenxixsw.com/yanqing/", script: "gen.js"},
        {title: "其他类型", input: "https://www.chenxixsw.com/qita/", script: "gen.js"},
        {title: "排行榜", input: "https://www.chenxixsw.com/paihangbang/", script: "gen.js"}

    ]);
}