let config_host = "http://localhost:1122";
// let config_host = "http://192.168.5.104:1122";


if (typeof host !== "undefined") {
    config_host = host
}