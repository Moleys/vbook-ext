function execute() {
    return Response.success([
        {title: "首页", input: "http://www.80k.net/", script: "gen.js"},
        {title: "玄幻奇幻", input:  "http://www.80k.net/category/xuanhuanqihuan", script: "gen.js"},
        {title: "现代言情", input:  "http://www.80k.net/category/xiandaiyanqing", script: "gen.js"},
        {title: "科幻灵异", input:  "http://www.80k.net/category/kehuanlingyi", script: "gen.js"},
        {title: "东方玄幻", input:  "http://www.80k.net/category/dongfangxuanhuan", script: "gen.js"},
        {title: "网游竞技", input:  "http://www.80k.net/category/wangyoujingji", script: "gen.js"},
        {title: "武侠仙侠", input:  "http://www.80k.net/category/wuxiaxianxia", script: "gen.js"},
        {title: "小说同人", input:  "http://www.80k.net/category/xiaoshuotongren", script: "gen.js"},
        {title: "女生频道", input:  "http://www.80k.net/category/nu:shengpindao", script: "gen.js"},
        {title: "都市言情", input:  "http://www.80k.net/category/dushiyanqing", script: "gen.js"},
        {title: "历史军事", input:  "http://www.80k.net/category/lishijunshi", script: "gen.js"}

    ]);
}