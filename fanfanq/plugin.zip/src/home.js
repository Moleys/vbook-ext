function execute() {
    return Response.success([
        {title: "魔幻网游", input: "http://bbs.fanfanq.com/ff118", script: "gen.js"},
        {title: "青春言情", input: "https://bbs.fanfanq.com/ff10", script: "gen.js"},
        {title: "轻松同人", input: "http://bbs.fanfanq.com/ff191", script: "gen.js"},
        {title: "科幻悬推", input: "http://bbs.fanfanq.com/ff62", script: "gen.js"},
        {title: "文学之殿", input: "http://bbs.fanfanq.com/ff60", script: "gen.js"},
        {title: "精品推荐", input: "http://bbs.fanfanq.com/ff216", script: "gen.js"},
        {title: "小说连载", input: "http://bbs.fanfanq.com/ff228", script: "gen.js"},
        {title: "耽美闲情", input: "http://bbs.fanfanq.com/ff117", script: "gen.js"}
        
    ]);
}