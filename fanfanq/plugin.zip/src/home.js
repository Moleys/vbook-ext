function execute() {
    return Response.success([
        {title: "魔幻网游", input: "http://bbs.fanfanc.com/ff118", script: "gen.js"},
        {title: "青春言情", input: "https://bbs.fanfanc.com/ff10", script: "gen.js"},
        {title: "轻松同人", input: "http://bbs.fanfanc.com/ff191", script: "gen.js"},
        {title: "科幻悬推", input: "http://bbs.fanfanc.com/ff62", script: "gen.js"},
        {title: "文学之殿", input: "http://bbs.fanfanc.com/ff60", script: "gen.js"},
        {title: "精品推荐", input: "http://bbs.fanfanc.com/ff216", script: "gen.js"},
        {title: "小说连载", input: "http://bbs.fanfanc.com/ff228", script: "gen.js"},
        {title: "耽美闲情", input: "http://bbs.fanfanc.com/ff117", script: "gen.js"}
        
    ]);
}