function execute() {
    return Response.success([
        {title: "玄幻", input:  "https://novel-api.xiaoppkk.com/h5/category-rank-category_id-1", script: "gen2.js"},
        {title: "武侠", input:  "https://novel-api.xiaoppkk.com/h5/category-rank-category_id-2", script: "gen2.js"},
        {title: "都市", input:  "https://novel-api.xiaoppkk.com/h5/category-rank-category_id-3", script: "gen2.js"},
        {title: "历史", input:  "https://novel-api.xiaoppkk.com/h5/category-rank-category_id-4", script: "gen2.js"},
        {title: "科幻", input:  "https://novel-api.xiaoppkk.com/h5/category-rank-category_id-5", script: "gen2.js"},
        {title: "网游", input:  "https://novel-api.xiaoppkk.com/h5/category-rank-category_id-6", script: "gen2.js"},
        {title: "女生", input:  "https://novel-api.xiaoppkk.com/h5/category-rank-category_id-7", script: "gen2.js"},
        {title: "同人", input:  "https://novel-api.xiaoppkk.com/h5/category-rank-category_id-66", script: "gen2.js"},
        {title: "竞技", input:  "https://m.38kanshu.com/fenlei/9/", script: "gen2.js"},
    ]);
}