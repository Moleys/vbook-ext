let BASE_URL = 'https://novelapi.qwezxc4.cn';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}