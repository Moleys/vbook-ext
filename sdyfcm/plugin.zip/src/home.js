function execute() {
    return Response.success([
        {title: "首页", input: "http://www.sdyfcm.com/", script: "gen.js"},
       {title: "玄幻小说", input: "http://www.sdyfcm.com/sort/1_1.html", script: "gen.js"},
       {title: "仙侠小说", input: "http://www.sdyfcm.com/sort/2_1.html", script: "gen.js"},
       {title: "都市小说", input: "http://www.sdyfcm.com/sort/3_1.html", script: "gen.js"},
       {title: "历史小说", input: "http://www.sdyfcm.com/sort/4_1.html", script: "gen.js"},
       {title: "网游小说", input: "http://www.sdyfcm.com/sort/5_1.html", script: "gen.js"},
       {title: "科幻小说", input: "http://www.sdyfcm.com/sort/6_1.html", script: "gen.js"},
       {title: "灵异小说", input: "http://www.sdyfcm.com/sort/7_1.html", script: "gen.js"},
       {title: "言情小说", input: "http://www.sdyfcm.com/sort/8_1.html", script: "gen.js"},
       {title: "其他小说", input: "http://www.sdyfcm.com/sort/9_1.html", script: "gen.js"}

    ]);
}