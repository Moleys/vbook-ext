function execute() {
    return Response.success([
        {title: "玄幻", input: "http://www.mengyuanshucheng.com/sort/xuanhuan", script: "zen.js"},
        {title: "奇幻", input: "http://www.mengyuanshucheng.com/sort/qihuan", script: "zen.js"},
        {title: "武侠", input: "http://www.mengyuanshucheng.com/sort/wuxia", script: "zen.js"},
        {title: "仙侠", input: "http://www.mengyuanshucheng.com/sort/xianxia", script: "zen.js"},
        {title: "都市", input: "http://www.mengyuanshucheng.com/sort/dushi", script: "zen.js"},
        {title: "历史", input: "http://www.mengyuanshucheng.com/sort/lishi", script: "zen.js"},
        {title: "军事", input: "http://www.mengyuanshucheng.com/sort/junshi", script: "zen.js"},
        {title: "游戏", input: "http://www.mengyuanshucheng.com/sort/youxi", script: "zen.js"},
        {title: "竞技", input: "http://www.mengyuanshucheng.com/sort/jingji", script: "zen.js"},
        {title: "科幻", input: "http://www.mengyuanshucheng.com/sort/kehuan", script: "zen.js"}

    ]);
}