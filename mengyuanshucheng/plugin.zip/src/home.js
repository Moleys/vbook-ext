function execute() {
    return Response.success([
        {title: "首页", input: "http://www.mengyuanshucheng.com/", script: "gen.js"},
        {title: "玄幻", input: "http://www.mengyuanshucheng.com/sort/xuanhuan.html", script: "gen.js"},
        {title: "奇幻", input: "http://www.mengyuanshucheng.com/sort/qihuan.html", script: "gen.js"},
        {title: "武侠", input: "http://www.mengyuanshucheng.com/sort/wuxia.html", script: "gen.js"},
        {title: "仙侠", input: "http://www.mengyuanshucheng.com/sort/xianxia.html", script: "gen.js"},
        {title: "都市", input: "http://www.mengyuanshucheng.com/sort/dushi.html", script: "gen.js"},
        {title: "历史", input: "http://www.mengyuanshucheng.com/sort/lishi.html", script: "gen.js"},
        {title: "军事", input: "http://www.mengyuanshucheng.com/sort/junshi.html", script: "gen.js"},
        {title: "游戏", input: "http://www.mengyuanshucheng.com/sort/youxi.html", script: "gen.js"},
        {title: "竞技", input: "http://www.mengyuanshucheng.com/sort/jingji.html", script: "gen.js"},
        {title: "科幻", input: "http://www.mengyuanshucheng.com/sort/kehuan.html", script: "gen.js"}

    ]);
}