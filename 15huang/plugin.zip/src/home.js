function execute() {
    return Response.success([
        {title: "玄幻奇幻", input:  "https://www.15huang.com/style/xhqh", script: "gen.js"},
        {title: "武侠仙侠", input:  "https://www.15huang.com/style/wxxx", script: "gen.js"},
        {title: "都市现实", input:  "https://www.15huang.com/style/dsxs", script: "gen.js"},
        {title: "历史军事", input:  "https://www.15huang.com/style/lsjs", script: "gen.js"},
        {title: "游戏体育", input:  "https://www.15huang.com/style/yxty", script: "gen.js"},
        {title: "科幻灵异", input:  "https://www.15huang.com/style/khly", script: "gen.js"},
        {title: "其他类别", input:  "https://www.15huang.com/style/cyhx", script: "gen.js"},
        {title: "最新小说", input:  "https://www.15huang.com/style/new/", script: "gen.js"},
        {title: "小说推荐", input:  "https://www.15huang.com/style/5stars/", script: "gen.js"}

    ]);
}