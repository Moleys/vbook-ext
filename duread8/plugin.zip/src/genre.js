function execute() {
    return Response.success([
        {title: "西幻传说", input:  "https://duread8.com/index/book_list/1/0/week_click/0/0/0/", script: "gen.js"},
        {title: "武侠仙侠", input:  "https://duread8.com/index/book_list/2/0/week_click/0/0/0/", script: "gen.js"},
        {title: "游戏动漫", input:  "https://duread8.com/index/book_list/3/0/week_click/0/0/0/", script: "gen.js"},
        {title: "科幻时空", input:  "https://duread8.com/index/book_list/4/0/week_click/0/0/0/", script: "gen.js"},
        {title: "都市逸闻", input:  "https://duread8.com/index/book_list/5/0/week_click/0/0/0/", script: "gen.js"},
        {title: "历史军事", input:  "https://duread8.com/index/book_list/6/0/week_click/0/0/0/", script: "gen.js"},
        {title: "诡异悬疑", input:  "https://duread8.com/index/book_list/7/0/week_click/0/0/0/", script: "gen.js"}

    ]);
}