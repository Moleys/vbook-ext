function execute() {
    return Response.success([
        {title: "全部", input:  "https://duread8.com/index/book_list/0/0/week_click/0/0/0/", script: "gen.js"}

    ]);
}