function execute() {
    return Response.success([
        {title: "玄幻", input:  "https://www.xsbiquge.net/class/xuanhuanxiaoshuo/", script: "zen.js"},
        {title: "仙侠", input:  "https://www.xsbiquge.net/class/xiuzhenxiaoshuo/", script: "zen.js"},
        {title: "都市", input:  "https://www.xsbiquge.net/class/dushixiaoshuo/", script: "zen.js"},
        {title: "历史", input:  "https://www.xsbiquge.net/class/lishijunshi/", script: "zen.js"},
        {title: "网游", input:  "https://www.xsbiquge.net/class/wangyouxiaoshuo/", script: "zen.js"},
        {title: "科幻", input:  "https://www.xsbiquge.net/class/kehuanxiaoshuo/", script: "zen.js"},
        {title: "女生", input:  "https://www.xsbiquge.net/class/nvshengxiaoshuo/", script: "zen.js"},
        {title: "其他", input:  "https://www.xsbiquge.net/class/qitaxiaoshuo/", script: "zen.js"}

    ]);
}