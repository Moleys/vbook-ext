function execute() {
    return Response.success([
        {title: "首页", input: "http://www.xsbiquge.net/", script: "gen.js"},
        {title: "玄幻", input:  "http://www.xsbiquge.net/class/xuanhuanxiaoshuo/1/", script: "gen.js"},
        {title: "仙侠", input:  "http://www.xsbiquge.net/class/xiuzhenxiaoshuo/1/", script: "gen.js"},
        {title: "都市", input:  "http://www.xsbiquge.net/class/dushixiaoshuo/1/", script: "gen.js"},
        {title: "历史", input:  "http://www.xsbiquge.net/class/lishijunshi/1/", script: "gen.js"},
        {title: "网游", input:  "http://www.xsbiquge.net/class/wangyouxiaoshuo/1/", script: "gen.js"},
        {title: "科幻", input:  "http://www.xsbiquge.net/class/kehuanxiaoshuo/1/", script: "gen.js"},
        {title: "女生", input:  "http://www.xsbiquge.net/class/nvshengxiaoshuo/1/", script: "gen.js"},
        {title: "其他", input:  "http://www.xsbiquge.net/class/qitaxiaoshuo/1/", script: "gen.js"}

    ]);
}