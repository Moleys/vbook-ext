let config_host = "http://localhost:1122";
let config_from = "zh";

// let config_host = "http://192.168.5.104:1122";


if (typeof host !== "undefined") {
    config_host = host
}

if (typeof lfrom !== "undefined") {
    config_from = lfrom
}