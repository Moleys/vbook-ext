function execute() {
    return Response.success([
        {title: "Kệ sách", input: "0", script: "gen.js"}
    ]);
}