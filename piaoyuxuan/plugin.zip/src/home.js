function execute() {
    return Response.success([
        {title: "最近更新", input: "https://www.piaoyuxuan.com/", script: "gen.js"}
    ]);
}