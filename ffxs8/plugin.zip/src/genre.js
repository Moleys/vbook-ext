function execute() {
    return Response.success([
        {title: "都市言情", input:  "http://www.ffxs8.com/dsyq/", script: "zen.js"},
        {title: "玄幻魔法", input:  "http://www.ffxs8.com/xhmf/", script: "zen.js"},
        {title: "武侠修真", input:  "http://www.ffxs8.com/wxxz/", script: "zen.js"},
        {title: "穿越架空", input:  "http://www.ffxs8.com/cyjk/", script: "zen.js"},
        {title: "科幻竞技", input:  "http://www.ffxs8.com/khjj/", script: "zen.js"},
        {title: "军事历史", input:  "http://www.ffxs8.com/jsls/", script: "zen.js"},
        {title: "鬼话悬疑", input:  "http://www.ffxs8.com/ghxy/", script: "zen.js"},
        {title: "耽美小说", input:  "http://www.ffxs8.com/smtr/", script: "zen.js"},
        {title: "同人小说", input:  "http://www.ffxs8.com/trxs/", script: "zen.js"},
        {title: "官场商战", input:  "http://www.ffxs8.com/gcsz/", script: "zen.js"},
        {title: "乡土风情", input:  "http://www.ffxs8.com/xtfq/", script: "zen.js"},
        {title: "总排行榜", input:  "http://www.ffxs8.com/sort/", script: "zen.js"}
    ]);
}