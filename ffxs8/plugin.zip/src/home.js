function execute() {
    return Response.success([
        {title: "首页", input:  "http://www.ffxs8.com/", script: "gen.js"},
        {title: "都市言情", input:  "http://www.ffxs8.com/dsyq/", script: "gen.js"},
        {title: "玄幻魔法", input:  "http://www.ffxs8.com/xhmf/", script: "gen.js"},
        {title: "武侠修真", input:  "http://www.ffxs8.com/wxxz/", script: "gen.js"},
        {title: "穿越架空", input:  "http://www.ffxs8.com/cyjk/", script: "gen.js"},
        {title: "科幻竞技", input:  "http://www.ffxs8.com/khjj/", script: "gen.js"},
        {title: "军事历史", input:  "http://www.ffxs8.com/jsls/", script: "gen.js"},
        {title: "鬼话悬疑", input:  "http://www.ffxs8.com/ghxy/", script: "gen.js"},
        {title: "耽美小说", input:  "http://www.ffxs8.com/smtr/", script: "gen.js"},
        {title: "同人小说", input:  "http://www.ffxs8.com/trxs/", script: "gen.js"},
        {title: "官场商战", input:  "http://www.ffxs8.com/gcsz/", script: "gen.js"},
        {title: "乡土风情", input:  "http://www.ffxs8.com/xtfq/", script: "gen.js"},
        {title: "总排行榜", input:  "http://www.ffxs8.com/sort/", script: "gen.js"}
    ]);
}