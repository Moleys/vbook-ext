function execute() {
    return Response.success([
        {title: "首页", input:  "http://www.ffxs8.com/", script: "gen.js"}
    ]);
}