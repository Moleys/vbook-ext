let BASE_URL = "https://backup.nhimmeo.cf";
if (typeof host !== "undefined") {
    BASE_URL = host
}