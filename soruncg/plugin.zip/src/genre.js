function execute() {
    return Response.success([
        {title: "玄幻奇幻", input:  "http://www.soruncg.com/ksl/1/", script: "gen2.js"},
        {title: "武侠仙侠", input:  "http://www.soruncg.com/ksl/2/", script: "gen2.js"},
        {title: "都市言情", input:  "http://www.soruncg.com/ksl/3/", script: "gen2.js"},
        {title: "历史军事", input:  "http://www.soruncg.com/ksl/4/", script: "gen2.js"},
        {title: "科幻灵异", input:  "http://www.soruncg.com/ksl/5/", script: "gen2.js"},
        {title: "网游竞技", input:  "http://www.soruncg.com/ksl/6/", script: "gen2.js"},
        {title: "女生频道", input:  "http://www.soruncg.com/ksl/7/", script: "gen2.js"},
    ]);
}