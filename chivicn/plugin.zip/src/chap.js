function execute(url) {
    url = url.split("/")
    let total_parts = url.pop();
    total_parts =  parseInt(total_parts, 10) + 1;
    url = url.join("/")
    // console.log(url)
    // console.log(total_parts)

    let cvdata = "";
    for(let i = 0; i < total_parts; i++){
        let response_parts = fetch(url+"/"+i);
        console.log(url+"/"+i)
        if (response_parts.ok) {
            let data_i = response_parts.json()
            let cvdata_i = data_i.cvdata;
            cvdata_i = cvdata_i.split("$\t$\t$\n")[2]
            cvdata_i = cvdata_i.replace(/\n/g,"<br>")
            
            cvdata = cvdata + cvdata_i;

        }
    }

    return Response.success(cvdata);

}

