function execute() {
    return Response.success([
		{title: "首页", input: "https://www.147xs.org/", script: "gen.js"},
		{title: "玄幻", input: "https://www.147xs.org/sort/1/", script: "gen.js"},
		{title: "修真", input: "https://www.147xs.org/sort/2/", script: "gen.js"},
		{title: "都市", input: "https://www.147xs.org/sort/3/", script: "gen.js"},
		{title: "历史", input: "https://www.147xs.org/sort/4/", script: "gen.js"},
		{title: "网游", input: "https://www.147xs.org/sort/5/", script: "gen.js"},
		{title: "科幻", input: "https://www.147xs.org/sort/6/", script: "gen.js"},
		{title: "次元", input: "https://www.147xs.org/sort/7/", script: "gen.js"},
		{title: "言情", input: "https://www.147xs.org/sort/8/", script: "gen.js"},
		{title: "青春", input: "https://www.147xs.org/sort/9/", script: "gen.js"},
		{title: "现代", input: "https://www.147xs.org/sort/10/", script: "gen.js"},
		{title: "古代", input: "https://www.147xs.org/sort/11/", script: "gen.js"},
		{title: "幻想", input: "https://www.147xs.org/sort/12/", script: "gen.js"},
		{title: "完本", input: "https://www.147xs.org/wanben/", script: "gen.js"}
    ]);
}