function execute(url, page) {
	url = url.replace('m.cool18.com', 'www.cool18.com');
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        const data = [];
		let ele1 = doc.select('#d_list li')
        ele1.select("ul li a").remove();
        ele1.select("ul li span").remove();
        ele1.select("ul li ul").remove();
        ele1.select("ul li").remove();

        ele1.forEach(e => {
                if(e.select("a").first().text()!='')
                    data.push({
                        name: e.select("a").first().text(),
                        // link: e.select("a").first().attr("href"),
                        link: e.select("a").last().attr("href"),
                        description: e.select("font").last().text(),
                        host: "https://wap.cool18.com/"
                    })
            }
        
        );


        return Response.success(data)
    }
    return null;
}