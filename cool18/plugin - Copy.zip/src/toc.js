function execute(url) {
	url = url.replace('m.cool18.com', 'www.cool18.com');
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        let el1 = doc.select(".ta-right").last()
        let el = el1.select("div.ta-show-list")
        console.log(el)
        const data = [];
        for (let i = 0;i < el.size(); i++) {
            var e = el.get(i);
            data.push({
                name: e.select("a").text(),
                url: e.select("a").first().attr("href"),
                host: "https://www.cool18.com"
            })
        }
        return Response.success(data);
    }
    return null;
}