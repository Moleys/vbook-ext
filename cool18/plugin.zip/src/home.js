function execute() {
    return Response.success([
        {title: "禁忌书屋", input: "https://www.cool18.com/bbs4/index.php", script: "gen.js"}

    ]);
}