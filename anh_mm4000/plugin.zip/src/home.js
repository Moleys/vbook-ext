function execute() {
    return Response.success([
        {title: "可爱", input:  "http://www.mm4000.com/meinv/keai", script: "gen.js"},
        {title: "甜美", input:  "http://www.mm4000.com/meinv/tianmei", script: "gen.js"},
        {title: "小清新", input:  "http://www.mm4000.com/meinv/xiaoqingxin", script: "gen.js"},
        {title: "美女", input:  "http://www.mm4000.com/meinv/xiezhen", script: "gen.js"},
        {title: "性感", input:  "http://www.mm4000.com/meinv/xinggan", script: "gen.js"},
        {title: "美女", input:  "http://www.mm4000.com/meinv/meinvtupian", script: "gen.js"},
        {title: "高清", input:  "http://www.mm4000.com/meinv/gaoqing", script: "gen.js"},
        {title: "性感美女", input:  "http://www.mm4000.com/meinv/xingganmeinv", script: "gen.js"},
        {title: "美女", input:  "http://www.mm4000.com/meinv/meinv", script: "gen.js"},
        {title: "诱惑", input:  "http://www.mm4000.com/meinv/youhuo", script: "gen.js"},
        {title: "清纯", input:  "http://www.mm4000.com/meinv/qingchun", script: "gen.js"},
        {title: "迷人", input:  "http://www.mm4000.com/meinv/miren", script: "gen.js"},
        {title: "气质", input:  "http://www.mm4000.com/meinv/qizhi", script: "gen.js"},
        {title: "模特", input:  "http://www.mm4000.com/meinv/mote", script: "gen.js"},
        {title: "唯美", input:  "http://www.mm4000.com/meinv/weimei", script: "gen.js"}

    ]);
}