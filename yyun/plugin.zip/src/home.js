function execute() {
    return Response.success([
		{title: "首页", input: "https://www.yyun.net/", script: "gen.js"},
		{title: "玄幻小说", input: "https://www.yyun.net/xuanhuanxiaoshuo/", script: "gen.js"},
		{title: "仙侠小说", input: "https://www.yyun.net/xianxiaxiaoshuo/", script: "gen.js"},
		{title: "都市小说", input: "https://www.yyun.net/dushixiaoshuo/", script: "gen.js"},
		{title: "军史小说", input: "https://www.yyun.net/junshixiaoshuo/", script: "gen.js"},
		{title: "网游小说", input: "https://www.yyun.net/wangyouxiaoshuo/", script: "gen.js"},
		{title: "科幻小说", input: "https://www.yyun.net/kehuanxiaoshuo/", script: "gen.js"},
		{title: "恐怖小说", input: "https://www.yyun.net/kongbuxiaoshuo/", script: "gen.js"},
		{title: "其他小说", input: "https://www.yyun.net/qitaxiaoshuo/", script: "gen.js"},
		{title: "完结小说", input: "https://www.yyun.net/quanbenxiaoshuo/1/", script: "gen.js"},
    ]);
}