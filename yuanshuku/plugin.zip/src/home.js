function execute() {
    return Response.success([
        {title: "首页", input: "http://www.yuanshuku.com/", script: "gen.js"},
        {title: "玄幻", input: "http://www.yuanshuku.com/sort/1_1/", script: "gen.js"},
        {title: "武侠", input: "http://www.yuanshuku.com/sort/2_1/", script: "gen.js"},
        {title: "都市", input: "http://www.yuanshuku.com/sort/3_1/", script: "gen.js"},
        {title: "言情", input: "http://www.yuanshuku.com/sort/4_1/", script: "gen.js"},
        {title: "历史", input: "http://www.yuanshuku.com/sort/5_1/", script: "gen.js"},
        {title: "科幻", input: "http://www.yuanshuku.com/sort/6_1/", script: "gen.js"},
        {title: "恐怖", input: "http://www.yuanshuku.com/sort/7_1/", script: "gen.js"},
        {title: "其他", input: "http://www.yuanshuku.com/sort/8_1/", script: "gen.js"},
        {title: "穿越", input: "http://www.yuanshuku.com/sort/9_1/", script: "gen.js"},
        {title: "游戏", input: "http://www.yuanshuku.com/sort/10_1/", script: "gen.js"},
        {title: "轻小说", input: "http://www.yuanshuku.com/sort/11_1/", script: "gen.js"},
        {title: "古言", input: "http://www.yuanshuku.com/sort/12_1/", script: "gen.js"},
        {title: "二次元", input: "http://www.yuanshuku.com/sort/13_1/", script: "gen.js"},
        {title: "青春", input: "http://www.yuanshuku.com/sort/14_1/", script: "gen.js"},
        {title: "同人", input: "http://www.yuanshuku.com/sort/15_1/", script: "gen.js"},
        {title: "GLBL", input: "http://www.yuanshuku.com/sort/16_1/", script: "gen.js"}

    ]);
}