load('config.js');
load('md5.js');

function execute(url, page) {
    if (!page) page = '1';
    let w = `comic/list?page=${page}`;
    let sign  = buildSign(w)
    let url2 = BASE_URL + "/api/" + w + "&sign=" + sign

    let response = fetch(url2);
    if (response.ok) {
        let doc = response.json();
        let data = [];
        doc.forEach(e => {
            let coverImg = e.imageUrl
            let link = BASE_URL2 + "/api/comic/detail/" + e.id
            data.push({
                name: e.name,
                link: link,
                cover: coverImg,
                description: "View: " + e.viewCount,
                host: BASE_URL2
            });
        });

        let next = parseInt(page, 10) + 1
        return Response.success(data, next.toString());
    }

    return null;
}