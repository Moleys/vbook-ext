load('config.js');
load('md5.js');

function execute(url, page) {
    let w = url.replace(BASE_URL2 + "/api/","")
    let sign  = buildSign(w)
    let url2 = BASE_URL + "/api/" + w + "?sign=" + sign
    console.log(url2)
    let response = fetch(url2);
    if (response.ok) {
        let doc = response.json();
        let el = doc.chapters;
        const data = [];
        for (let i = 0; i < el.length; i++) {
            let e = el[i];
            data.push({
                name: e.title,
                url: BASE_URL2 + "/api/chapter/detail/" + e.id,
                host: BASE_URL2
            })
        }
        data = data.reverse();
        return Response.success(data);
    }

    return null;
}