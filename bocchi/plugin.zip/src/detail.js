load('config.js');
load('md5.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL2);
    let w = url.replace(BASE_URL2 + "/api/","")
    let sign  = buildSign(w)
    let url2 = BASE_URL + "/api/" + w + "?sign=" + sign
    console.log(url2)
    let response = fetch(url2);

    if (response.ok) {
        let doc = response.json();
        let coverImg = doc.imageUrl
        let genres = [];
        doc.genres.forEach(e => {
            genres.push({
                title: e.name,
                input: e.id,
                script: "gen2.js"
            });
        });



        let detail = "Tác giả: " + doc.author + "<br>Theo dõi: " + doc.followCount + "<br>Bình luận: " + doc.commentCount + "<br>Lượt xem: " + doc.viewCount
        
        return Response.success({
            name: doc.name,
            cover: coverImg,
            author: doc.author,
            description: doc.description.replace(/\r?\n/g,"<br>"),
            detail: detail,
            ongoing: doc.status.indexOf("Đang tiến hành") >= 0,
            genres: genres,
            host: BASE_URL2
        });
    }

    return null;
}