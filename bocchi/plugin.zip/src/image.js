function execute(url) {
    let response = fetch(url, {
        headers: {
            'referer': 'http://localhost/',
            'vvx' : "hh2"
        }
    });
    if (response.ok) {
        return Graphics.createImage(response.base64())
    }

    return null;
}