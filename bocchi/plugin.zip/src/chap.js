load('config.js');
load('md5.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL2);
    let w = url.replace(BASE_URL2 + "/api/","")
    let sign  = buildSign(w)
    let url2 = BASE_URL + "/api/" + w + "?sign=" + sign
    console.log(url2)
    let response = fetch(url2);
    if (response.ok) {
        let doc = response.json();
        let data = [];
        doc.images.forEach(e => {
            let img = e.imageUrl;
            data.push({
                link: img,
                script: "image.js"
            })
            
        });
        return Response.success(data);
    }
    return null;
}