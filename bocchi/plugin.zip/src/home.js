load('config.js');
function execute() {
    return Response.success([
        {title: "Mới cập nhật", input: "1", script: "gen.js"},
    ]);
}