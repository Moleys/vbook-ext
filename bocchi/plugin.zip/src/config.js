let BASE_URL = 'https://www.pintruyen.com';
let BASE_URL2 = 'https://www.fbi.com';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}