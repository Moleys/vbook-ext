function execute() {
    return Response.success([
        {title: "玄幻小说", input:  "http://www.665txt.com/txtsort/1/", script: "zen.js"},
        {title: "武侠修真", input:  "http://www.665txt.com/txtsort/2/", script: "zen.js"},
        {title: "都市言情", input:  "http://www.665txt.com/txtsort/3/", script: "zen.js"},
        {title: "历史军事", input:  "http://www.665txt.com/txtsort/4/", script: "zen.js"},
        {title: "网游竞技", input:  "http://www.665txt.com/txtsort/5/", script: "zen.js"},
        {title: "科幻小说", input:  "http://www.665txt.com/txtsort/6/", script: "zen.js"},
        {title: "恐怖灵异", input:  "http://www.665txt.com/txtsort/7/", script: "zen.js"},
        {title: "其他类型", input:  "http://www.665txt.com/txtsort/10/", script: "zen.js"}
    ]);
}