function execute() {
    return Response.success([
        {title: "玄幻奇幻", input: "https://www.wdbqg.com/sort/1_", script: "zen.js"},
        {title: "武侠仙侠", input: "https://www.wdbqg.com/sort/2_", script: "zen.js"},
        {title: "都市言情", input: "https://www.wdbqg.com/sort/3_", script: "zen.js"},
        {title: "历史军事", input: "https://www.wdbqg.com/sort/4_", script: "zen.js"},
        {title: "网游竞技", input: "https://www.wdbqg.com/sort/5_", script: "zen.js"},
        {title: "科幻灵异", input: "https://www.wdbqg.com/sort/6_", script: "zen.js"},
        {title: "女生频道", input: "https://www.wdbqg.com/sort/7_", script: "zen.js"},
        {title: "其他小说", input: "https://www.wdbqg.com/sort/8_", script: "zen.js"}

    ]);
}