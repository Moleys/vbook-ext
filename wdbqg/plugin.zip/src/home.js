function execute() {
    return Response.success([
        {title: "首页", input: "https://www.wdbqg.com/", script: "gen.js"},
        {title: "玄幻奇幻", input: "https://www.wdbqg.com/sort/1_1/", script: "gen.js"},
        {title: "武侠仙侠", input: "https://www.wdbqg.com/sort/2_1/", script: "gen.js"},
        {title: "都市言情", input: "https://www.wdbqg.com/sort/3_1/", script: "gen.js"},
        {title: "历史军事", input: "https://www.wdbqg.com/sort/4_1/", script: "gen.js"},
        {title: "网游竞技", input: "https://www.wdbqg.com/sort/5_1/", script: "gen.js"},
        {title: "科幻灵异", input: "https://www.wdbqg.com/sort/6_1/", script: "gen.js"},
        {title: "女生频道", input: "https://www.wdbqg.com/sort/7_1/", script: "gen.js"},
        {title: "其他小说", input: "https://www.wdbqg.com/sort/8_1/", script: "gen.js"}

    ]);
}