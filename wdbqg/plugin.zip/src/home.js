function execute() {
    return Response.success([
        {title: "首页", input: "http://www.wdbqg.com/", script: "gen.js"},
    ]);
}