function execute() {
    return Response.success([
        {title: "首页", input: "https://www.uuks.org/", script: "gen.js"},
        {title: "玄幻小说", input: "https://www.uuks.org/list1/", script: "gen.js"},
        {title: "仙侠修真", input: "https://www.uuks.org/list2/", script: "gen.js"},
        {title: "都市现代", input: "https://www.uuks.org/list3/", script: "gen.js"},
        {title: "军史穿越", input: "https://www.uuks.org/list4/", script: "gen.js"},
        {title: "网游竞技", input: "https://www.uuks.org/list5/", script: "gen.js"},
        {title: "恐怖科幻", input: "https://www.uuks.org/list6/", script: "gen.js"},
        {title: "同人次元", input: "https://www.uuks.org/list7/", script: "gen.js"},
        {title: "综合言情", input: "https://www.uuks.org/list8/", script: "gen.js"},
        {title: "浪漫青春", input: "https://www.uuks.org/list9/", script: "gen.js"},
        {title: "全本小说", input: "https://www.uuks.org/wanben/", script: "gen.js"}

    ]);
}