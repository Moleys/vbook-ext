function execute() {
    return Response.success([
        {title: "全部", input:  "https://www.shenyekanshu.com/category/0/", script: "gen.js"}

    ]);
}