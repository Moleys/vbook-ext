function execute() {
    return Response.success([
        {title: "玄幻", input: "https://www.vipkanshu.vip/class/1-", script: "zen.js"},
        {title: "修真", input: "https://www.vipkanshu.vip/class/2-", script: "zen.js"},
        {title: "都市", input: "https://www.vipkanshu.vip/class/3-", script: "zen.js"},
        {title: "历史", input: "https://www.vipkanshu.vip/class/4-", script: "zen.js"},
        {title: "网游", input: "https://www.vipkanshu.vip/class/5-", script: "zen.js"},
        {title: "科幻", input: "https://www.vipkanshu.vip/class/6-", script: "zen.js"},
        {title: "其他", input: "https://www.vipkanshu.vip/class/7-", script: "zen.js"},
        {title: "全本", input: "https://www.vipkanshu.vip/quanben/0_", script: "zen.js"},

    ]);
}