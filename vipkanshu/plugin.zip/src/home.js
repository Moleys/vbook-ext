function execute() {
    return Response.success([
        {title: "首页", input: "https://www.vipkanshu.vip/", script: "gen.js"},
        {title: "玄幻", input: "https://www.vipkanshu.vip/class/1-1.html", script: "gen.js"},
        {title: "修真", input: "https://www.vipkanshu.vip/class/2-1.html", script: "gen.js"},
        {title: "都市", input: "https://www.vipkanshu.vip/class/3-1.html", script: "gen.js"},
        {title: "历史", input: "https://www.vipkanshu.vip/class/4-1.html", script: "gen.js"},
        {title: "网游", input: "https://www.vipkanshu.vip/class/5-1.html", script: "gen.js"},
        {title: "科幻", input: "https://www.vipkanshu.vip/class/6-1.html", script: "gen.js"},
        {title: "其他", input: "https://www.vipkanshu.vip/class/7-1.html", script: "gen.js"},
        {title: "全本", input: "https://www.vipkanshu.vip/quanben/", script: "gen.js"},
        {title: "排行榜", input: "https://www.vipkanshu.vip/paihangbang/", script: "gen.js"}

    ]);
}