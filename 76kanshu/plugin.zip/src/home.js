function execute() {
    return Response.success([
        {title: "玄幻", input:  "http://www.76kanshu.com/fenlei/1/", script: "gen.js"},
        {title: "奇幻", input:  "http://www.76kanshu.com/fenlei/2/", script: "gen.js"},
        {title: "武侠", input:  "http://www.76kanshu.com/fenlei/3/", script: "gen.js"},
        {title: "仙侠", input:  "http://www.76kanshu.com/fenlei/4/", script: "gen.js"},
        {title: "都市", input:  "http://www.76kanshu.com/fenlei/5/", script: "gen.js"},
        {title: "军事", input:  "http://www.76kanshu.com/fenlei/6/", script: "gen.js"},
        {title: "历史", input:  "http://www.76kanshu.com/fenlei/7/", script: "gen.js"},
        {title: "游戏", input:  "http://www.76kanshu.com/fenlei/8/", script: "gen.js"},
        {title: "科幻", input:  "http://www.76kanshu.com/fenlei/10/", script: "gen.js"},
        {title: "灵异", input:  "http://www.76kanshu.com/fenlei/12/", script: "gen.js"},
        {title: "古代言情", input:  "http://www.76kanshu.com/fenlei/14/", script: "gen.js"},
        {title: "现代言情", input:  "http://www.76kanshu.com/fenlei/16/", script: "gen.js"},
        {title: "二次元", input:  "http://www.76kanshu.com/fenlei/24/", script: "gen.js"}

    ]);
}