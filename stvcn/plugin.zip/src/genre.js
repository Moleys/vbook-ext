function execute() {
    return Response.success([
        {title: "Huyền Huyễn", input: "https://sangtacviet.info/?find=&minc=0&category=hh&tag=", script: "gen.js"},
        {title: "Đô Thị", input: "https://sangtacviet.info/?find=&minc=0&category=dt&tag=", script: "gen.js"},
        {title: "Ngôn Tình", input: "https://sangtacviet.info/?find=&minc=0&category=nt&tag=", script: "gen.js"},
        {title: "Võng Du", input: "https://sangtacviet.info/?find=&minc=0&category=vd&tag=", script: "gen.js"},
        {title: "Khoa Học Viễn Tưởng", input: "https://sangtacviet.info/?find=&minc=0&category=kh&tag=", script: "gen.js"},
        {title: "Dị Năng", input: "https://sangtacviet.info/?find=&minc=0&category=dna&tag=", script: "gen.js"},
        {title: "Đồng Nhân", input: "https://sangtacviet.info/?find=&minc=0&category=dn&tag=", script: "gen.js"},
        {title: "Linh Dị", input: "https://sangtacviet.info/?find=&minc=0&category=ld&tag=", script: "gen.js"}
    ]);
}