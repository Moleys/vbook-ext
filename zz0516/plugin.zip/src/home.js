function execute() {
    return Response.success([
        {title: "首页", input: "http://www.zz0516.com/", script: "gen.js"},
        {title: "玄幻小说", input:  "http://www.zz0516.com/xuanhuan/", script: "gen.js"},
        {title: "修真小说", input:  "http://www.zz0516.com/xiuzhen/", script: "gen.js"},
        {title: "都市小说", input:  "http://www.zz0516.com/dushi/", script: "gen.js"},
        {title: "历史小说", input:  "http://www.zz0516.com/lishi/", script: "gen.js"},
        {title: "网游小说", input:  "http://www.zz0516.com/wangyou/", script: "gen.js"},
        {title: "科幻小说", input:  "http://www.zz0516.com/kehuan/", script: "gen.js"},
        {title: "女频小说", input:  "http://www.zz0516.com/nvpin/", script: "gen.js"},
        {title: "书库", input:  "http://www.zz0516.com/xiaoshuodaquan", script: "gen.js"},
        {title: "全本小说", input:  "http://www.zz0516.com/quanben/", script: "gen.js"},
        {title: "排行榜", input:  "http://www.zz0516.com/paihangbang/", script: "gen.js"}

    ]);
}