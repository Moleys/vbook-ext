function execute() {
    return Response.success([
        {title: "全部", input: "-1", script: "gen.js"},

    ]);
}