function execute(url, page) {
    const data = [];
    data.push({
        name: "#non-hentai",
        link: "https://hentaiz.cc/gallery/?channels%5B%5D=616622316356501515",
        host: "https://hentaiz.cc/gallery/"
    })

    data.push({
        name: "#ảnh-ecchi-hentai-18",
        link: "https://hentaiz.cc/gallery/?channels%5B%5D=616616204781617152",
        host: "https://hentaiz.cc/gallery/"
    })

    data.push({
        name: "#video-hentai",
        link: "https://hentaiz.cc/gallery/?channels%5B%5D=620657451687084042",
        host: "https://hentaiz.cc/gallery/"
    })

    data.push({
        name: "#3D-hentai",
        link: "https://hentaiz.cc/gallery/?channels%5B%5D=852377613498318888",
        host: "https://hentaiz.cc/gallery/"
    })

    data.push({
        name: "#video-irl",
        link: "https://hentaiz.cc/gallery/?channels%5B%5D=620657953917370378",
        host: "https://hentaiz.cc/gallery/"
    })

    data.push({
        name: "#ảnh-gái-xinh",
        link: "https://hentaiz.cc/gallery/?channels%5B%5D=781870041862897684",
        host: "https://hentaiz.cc/gallery/"
    })

    data.push({
        name: "#ảnh-gái-xinh-18",
        link: "https://hentaiz.cc/gallery/?channels%5B%5D=781870218192355329",
        host: "https://hentaiz.cc/gallery/"
    })

    data.push({
        name: "#yuri",
        link: "https://hentaiz.cc/gallery/?channels%5B%5D=616622475773476884",
        host: "https://hentaiz.cc/gallery/"
    })

    data.push({
        name: "#futa",
        link: "https://hentaiz.cc/gallery/?channels%5B%5D=616622496765968427",
        host: "https://hentaiz.cc/gallery/"
    })

    data.push({
        name: "#yaoi",
        link: "https://hentaiz.cc/gallery/?channels%5B%5D=622677459690717185",
        host: "https://hentaiz.cc/gallery/"
    })

    data.push({
        name: "#furry",
        link: "https://hentaiz.cc/gallery/?channels%5B%5D=622677550065516554",
        host: "https://hentaiz.cc/gallery/"
    })
    return Response.success(data)
}