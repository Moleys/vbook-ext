function execute() {
    return Response.success([
        {title: "Chủ đề", input:  "list", script: "gen.js"},

    ]);
}