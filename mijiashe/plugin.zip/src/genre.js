function execute() {
    return Response.success([
        {title: "玄幻", input:  "https://m.38kanshu.com/fenlei/", script: "gen.js"},
        {title: "奇幻", input:  "https://m.38kanshu.com/fenlei/2/", script: "gen.js"},
        {title: "武侠", input:  "https://m.38kanshu.com/fenlei/3/", script: "gen.js"},
        {title: "仙侠", input:  "https://m.38kanshu.com/fenlei/4/", script: "gen.js"},
        {title: "都市", input:  "https://m.38kanshu.com/fenlei/5/", script: "gen.js"},
        {title: "军事", input:  "https://m.38kanshu.com/fenlei/6/", script: "gen.js"},
        {title: "历史", input:  "https://m.38kanshu.com/fenlei/7/", script: "gen.js"},
        {title: "游戏", input:  "https://m.38kanshu.com/fenlei/8/", script: "gen.js"},
        {title: "竞技", input:  "https://m.38kanshu.com/fenlei/9/", script: "gen.js"},
        {title: "科幻", input:  "https://m.38kanshu.com/fenlei/10/", script: "gen.js"},
        {title: "悬疑", input:  "https://m.38kanshu.com/fenlei/1", script: "gen.js"},
        {title: "灵异", input:  "https://m.38kanshu.com/fenlei/12/", script: "gen.js"},
        {title: "其他", input:  "https://m.38kanshu.com/fenlei/13/", script: "gen.js"},
        {title: "古代言情", input:  "https://m.38kanshu.com/fenlei/14/", script: "gen.js"},
        {title: "仙侠奇缘", input:  "https://m.38kanshu.com/fenlei/15/", script: "gen.js"},
        {title: "现代言情", input:  "https://m.38kanshu.com/fenlei/16/", script: "gen.js"},
        {title: "浪漫青春", input:  "https://m.38kanshu.com/fenlei/17/", script: "gen.js"},
        {title: "玄幻言情", input:  "https://m.38kanshu.com/fenlei/18/", script: "gen.js"},
        {title: "悬疑灵异", input:  "https://m.38kanshu.com/fenlei/19/", script: "gen.js"},
        {title: "科幻空间", input:  "https://m.38kanshu.com/fenlei/20/", script: "gen.js"},
        {title: "游戏竞技", input:  "https://m.38kanshu.com/fenlei/2", script: "gen.js"},
        {title: "BL文", input:  "https://m.38kanshu.com/fenlei/22/", script: "gen.js"},
        {title: "GL文", input:  "https://m.38kanshu.com/fenlei/23/", script: "gen.js"},
        {title: "二次元", input:  "https://m.38kanshu.com/fenlei/24/", script: "gen.js"}
    ]);
}