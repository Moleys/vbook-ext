function execute() {
    return Response.success([
        {title: "全部分类", input:  "https://m.mijiashe.com/fenlei/", script: "gen.js"}
    ]);
}