function execute() {
    return Response.success([
        {title: "全部分类", input:  "https://m.38kanshu.com/fenlei/", script: "gen.js"}
    ]);
}