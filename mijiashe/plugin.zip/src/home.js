function execute() {
    return Response.success([
        {title: "首页", input: "http://www.mijiashe.com/", script: "gen.js"},
        {title: "玄幻", input:  "http://www.mijiashe.com/fenlei/1/1/", script: "gen.js"},
        {title: "奇幻", input:  "http://www.mijiashe.com/fenlei/2/1/", script: "gen.js"},
        {title: "武侠", input:  "http://www.mijiashe.com/fenlei/3/1/", script: "gen.js"},
        {title: "仙侠", input:  "http://www.mijiashe.com/fenlei/4/1/", script: "gen.js"},
        {title: "都市", input:  "http://www.mijiashe.com/fenlei/5/1/", script: "gen.js"},
        {title: "军事", input:  "http://www.mijiashe.com/fenlei/6/1/", script: "gen.js"},
        {title: "历史", input:  "http://www.mijiashe.com/fenlei/7/1/", script: "gen.js"},
        {title: "游戏", input:  "http://www.mijiashe.com/fenlei/8/1/", script: "gen.js"},
        {title: "科幻", input:  "http://www.mijiashe.com/fenlei/10/1/", script: "gen.js"},
        {title: "二次元", input:  "http://www.mijiashe.com/fenlei/24/1/", script: "gen.js"}

    ]);
}