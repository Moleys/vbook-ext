function execute(url) {
    return Response.success({
        name: "Moleys's Girls Collection",
        cover: "https://i.imgur.com/a2ztHgtm.jpg",
        author: "Moleys",
        description: "Hí hí",
        detail: "Sưu tầm",
        host: "http://www.mm4000.com/meinv/",
        type: "comic"

    });
}