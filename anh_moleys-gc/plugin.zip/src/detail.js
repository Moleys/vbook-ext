function execute(url) {
    return Response.success({
        name: "Bộ sưu tập ảnh gái xinh của Mol",
        cover: "https://i.imgur.com/a2ztHgtm.jpg",
        author: "Moleys",
        description: "╰(*´︶`*)╯♡	",
        detail: "Sưu tầm",
        host: "http://github.com/Moleys/vbook-ext/anh_moleys-gc/",
        type: "comic"

    });
}