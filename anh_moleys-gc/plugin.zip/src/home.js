function execute() {
    return Response.success([
        {title: "Trang chủ", input:  "1", script: "gen.js"}

    ]);
}