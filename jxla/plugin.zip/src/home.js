function execute() {
    return Response.success([
        {title: "最近更新", input: "http://www.jx.la/", script: "gen.js"}

    ]);
}