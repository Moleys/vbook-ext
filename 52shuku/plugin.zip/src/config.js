let BASE_URL = 'https://www.52shuku.vip';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}
