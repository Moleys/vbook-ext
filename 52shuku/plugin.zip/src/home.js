function execute() {
    return Response.success([
        {title: "言情小说", input:  "https://www.52shuku.net/yanqing/", script: "gen.js"},

    ]);
}