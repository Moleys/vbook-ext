function execute() {
    return Response.success([
        {title: "言情小说", input:  "https://www.52shuku.vip/yanqing/", script: "gen.js"},

    ]);
}