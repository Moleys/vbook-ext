function execute() {
    return Response.success([
        {title: "综漫同人", input:  "https://www.52shuku.vip/bl/", script: "gen.js"},
        {title: "GL百合", input:  "https://www.52shuku.vip/gl/", script: "gen.js"},

        {title: "古架耽美", input:  "https://www.52shuku.vip/jiakong/", script: "gen.js"},
        {title: "穿越耽美", input:  "https://www.52shuku.vip/chongsheng/", script: "gen.js"},
        {title: "现代耽美", input:  "https://www.52shuku.vip/xiandaidushi/", script: "gen.js"},

        {title: "现代都市_男频", input:  "https://www.52shuku.vip/xiandai/", script: "gen.js"},
        {title: "武侠玄幻_男频", input:  "https://www.52shuku.vip/wuxia/", script: "gen.js"},
        {title: "穿越重生_男频", input:  "https://www.52shuku.vip/chuanyue/", script: "gen.js"},
        {title: "架空历史_男频", input:  "https://www.52shuku.vip/jiakonglishi/", script: "gen.js"},
        {title: "网游竞技_男频", input:  "https://www.52shuku.vip/wangyou/", script: "gen.js"},

        {title: "悬疑推理小说", input:  "https://www.52shuku.vip/tuili/", script: "gen.js"},
        {title: "恐怖灵异小说", input:  "https://www.52shuku.vip/kongbulingyi/", script: "gen.js"},
        {title: "文学著作", input:  "https://www.52shuku.vip/wenxue/", script: "gen.js"}

    ]);
}