function execute() {
    return Response.success([
        {title: "综漫同人", input:  "https://www.52shuku.net/bl/", script: "gen.js"},
        {title: "GL百合", input:  "https://www.52shuku.net/gl/", script: "gen.js"},

        {title: "古架耽美", input:  "https://www.52shuku.net/jiakong/", script: "gen.js"},
        {title: "穿越耽美", input:  "https://www.52shuku.net/chongsheng/", script: "gen.js"},
        {title: "现代耽美", input:  "https://www.52shuku.net/xiandaidushi/", script: "gen.js"},

        {title: "现代都市_男频", input:  "https://www.52shuku.net/xiandai/", script: "gen.js"},
        {title: "武侠玄幻_男频", input:  "https://www.52shuku.net/wuxia/", script: "gen.js"},
        {title: "穿越重生_男频", input:  "https://www.52shuku.net/chuanyue/", script: "gen.js"},
        {title: "架空历史_男频", input:  "https://www.52shuku.net/jiakonglishi/", script: "gen.js"},
        {title: "网游竞技_男频", input:  "https://www.52shuku.net/wangyou/", script: "gen.js"},

        {title: "悬疑推理小说", input:  "https://www.52shuku.net/tuili/", script: "gen.js"},
        {title: "恐怖灵异小说", input:  "https://www.52shuku.net/kongbulingyi/", script: "gen.js"},
        {title: "文学著作", input:  "https://www.52shuku.net/wenxue/", script: "gen.js"}

    ]);
}