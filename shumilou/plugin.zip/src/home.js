function execute() {
    return Response.success([
        {title: "首页", input: "http://www.shumilou.co/", script: "gen.js"}

    ]);
}