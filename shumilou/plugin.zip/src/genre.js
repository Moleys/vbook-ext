function execute() {
    return Response.success([
        { title: "玄幻", input: "http://www.shumilouxs.com/list/xuanhuanmofa/", script: "zen.js" },
        { title: "仙侠", input: "http://www.shumilouxs.com/list/xianxiaxiuzhen/", script: "zen.js" },
        { title: "都市", input: "http://www.shumilouxs.com/list/dushuyanqing/", script: "zen.js" },
        { title: "历史", input: "http://www.shumilouxs.com/list/lishijunshi/", script: "zen.js" },
        { title: "网游", input: "http://www.shumilouxs.com/list/wangyoudongman/", script: "zen.js" },
        { title: "科幻", input: "http://www.shumilouxs.com/list/kehuanxiaoshuo/", script: "zen.js" },
        { title: "女生", input: "http://www.shumilouxs.com/list/nvshengxiaoshuo/", script: "zen.js" },
        { title: "其他", input: "http://www.shumilouxs.com/list/qitaxiaoshuo/", script: "zen.js" }
    ]);
}