package com.dai.getnames;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.helper.HttpConnection;
import org.jsoup.nodes.Document;
//import org.jsoup.nodes.Element;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
//import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
//import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.IOException;
import java.io.OutputStream;
import java.text.Normalizer;
//import java.util.ArrayList;
//import java.util.List;
import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Pattern;

import android.os.AsyncTask;
import android.widget.Toast;

import com.eclipsesource.json.Json;
import com.eclipsesource.json.JsonArray;
import com.eclipsesource.json.JsonObject;
import com.eclipsesource.json.JsonValue;


public class MainActivity extends AppCompatActivity {

    private EditText resultText;
    private ProgressDialog progressDialog;
    public String fcontent;
    public String fname;



    // slug vietnamese
    public String slug(String str) {
        String str1 = Normalizer.normalize(str, Normalizer.Form.NFD);
        Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
        String str2 = pattern.matcher(str1).replaceAll("").toLowerCase(Locale.ENGLISH).replaceAll("đ", "d").replaceAll(" ", "-");
        return str2;
    }

    ArrayList<String> jsonStringToArray(String jsonString) throws JSONException {
        ArrayList<String> stringArray = new ArrayList<String>();
        JSONArray jsonArray = new JSONArray(jsonString);
        for (int i = 0; i < jsonArray.length(); i++) {
            stringArray.add(jsonArray.getString(i));
        }
        return stringArray;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText editUrl = (EditText)findViewById(R.id.editURL);
        Button buttonGetData = (Button)findViewById(R.id.button_get_data);
        Button buttonSave = (Button)findViewById(R.id.button_save);
        Button buttonPaste = (Button)findViewById(R.id.button_paste);
        resultText = (EditText)findViewById(R.id.edit_result);
        editUrl.setText("");
        resultText.setText("");

        buttonGetData.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String siteUrl = editUrl.getText().toString();
                new PareseURL().execute(new String[]{siteUrl});
            }
        });
        buttonPaste.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                try {
                    ClipboardManager manager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    ClipData pasteData = manager.getPrimaryClip();
                    ClipData.Item item = pasteData.getItemAt(0);
                    String pasteText = item.getText().toString();
                    editUrl.setText(pasteText);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, "Nothing in clipboard", Toast.LENGTH_SHORT).show();
                }

            }
        });
        buttonSave.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                fcontent = resultText.getText().toString().trim();

                String linkName = editUrl.getText().toString();
                if(linkName.contains("https://wiki") ==true || linkName.contains("http://wiki") ==true){
                    String link0 = linkName.substring(linkName.lastIndexOf('/') + 1);
                    String link1 = link0.substring(link0.lastIndexOf('-') + 1);
                    linkName = link0.replace("-" + link1,"");
                }
                else if (linkName.contains("chiasename.blogspot.com")  ==true || linkName.contains("chiasenames.blogspot.com") ==true){

                    String link0 = linkName.substring(linkName.lastIndexOf('/') + 1);
                    linkName = link0.replace(".html?m=1","");
                    linkName = linkName.replace(".html","");
                    linkName = linkName.replace("name-","");
                }
                else if(linkName.contains("https://sangtacviet") ==true || linkName.contains("http://sangtacviet") ==true){
                    linkName = fname;
                }
                else if(linkName.contains("https://chivi") ==true || linkName.contains("http://chivi") ==true){
                    linkName = slug(fname);
                }

                else{
                    linkName = "";
                }

                long unixTime = System.currentTimeMillis() / 1000L;
                String fileName = "Names_" + linkName +"_"  + unixTime +".txt";

                createAndSaveFile(fileName);


            }
        });
    }



    private class PareseURL extends AsyncTask<String, Void, String>{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            showProgessDialog();
        }

        @RequiresApi(api = Build.VERSION_CODES.O)
        @Override
        protected String doInBackground(String... params) {
            StringBuffer buffer = new StringBuffer();
            String siteUrl = params[0];
            //wikidich
            if(siteUrl.contains("https://wiki") ==true || siteUrl.contains("http://wiki") ==true){
                try {
                    Document document = Jsoup.connect(siteUrl).get();
                    Elements ul = document.select("#listName");
                    Elements li = ul.select("li"); // select all li from ul
                    for (int i = 0; i < li.size(); i++) {
                        buffer.append(li.get(i).text() + "\r\n");
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            //chivi
            else if(siteUrl.contains("https://chivi") ==true || siteUrl.contains("http://chivi") ==true){
                try {

                    if(siteUrl.contains("/dicts/") ==false){
                        Document documentk = Jsoup.connect(siteUrl).get();
                        Element contentk = documentk.select("a.m-btn").last();
                        siteUrl = "https://chivi.app" + contentk.attr("href");
                    }


                    if( siteUrl.contains("?pg")==true){
                        siteUrl = siteUrl.split("\\?pg=")[0];
                    }
                    //lấy tổng page trang chivi
                    Document document1 = Jsoup.connect(siteUrl+"?pg=9999").get();
                    Elements contentx = document1.select("h2");
                    //lấy tên truyện
                    fname = document1.select("title").text().split(":")[1].replace("- Chivi","").trim();

                    String totalWords = contentx.text().split(":")[1].trim();
                    float totalPages = (float) Integer.parseInt(totalWords)/25;
                    int totalPagesTrue = (int) Math.ceil(totalPages);
                    //xong lấy tổng

                    //lấy tất cả các  trang
                    String allNames = "";
                    int pageCount = totalPagesTrue;


                    for (int i = 1; i <= pageCount; i++) {
                        String url = siteUrl.replace("/dicts/","/api/dicts/") + "?pg=" + i;
                        //một trang
                        Connection  con = HttpConnection.connect(url);
                        con.method(Connection.Method.GET).data().ignoreContentType(true);
                        Connection.Response resp = con.execute();
                        String content = "{\"terms\":" + resp.body().toString().split(",\"terms\":")[1].split(",\"cache\":")[0];
                        JsonObject object = Json.parse(content).asObject();
                        JsonArray terms_list = object.get("terms").asArray();

                        for (int j = 0; j < terms_list.size(); j++) {
                            String term_key = terms_list.get(j).asObject().get("key").asString();
                            String term_val = terms_list.get(j).asObject().get("val").asArray().get(0).asString();
                            Integer term_flag = terms_list.get(j).asObject().get("_flag").asInt();
                            String term_tag = terms_list.get(j).asObject().get("ptag").asString();
                            if(term_flag == 0 && term_val.length()>0){
                                allNames +=  term_key+"=" + term_val + "\r\n";
                            }
                        }

                        //xong get 1 trang



                    }






                    buffer.append(allNames+ "\r\n");

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }


            //chiasename
            else if (siteUrl.contains("chiasename.blogspot.com")  ==true || siteUrl.contains("chiasenames.blogspot.com") ==true){
                try {
                    Document document = Jsoup.connect(siteUrl).get();
                    Elements div = document.select(".entry-content");
                    Elements li = div.select("p");
                    for (int i = 0; i < li.size(); i++) {
                        buffer.append(li.get(i).text() + "\r\n");
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            //sangtacviet
            else if(siteUrl.contains("https://sangtacviet") ==true || siteUrl.contains("http://sangtacviet") ==true){
                try {
                    String siteUrl1 = "https://sangtacviet.info/namesys.php?host=";
                    Document document0 = Jsoup.connect(siteUrl).get();
                    Elements div0 = document0.select("#hiddenid");
                    String temp0 = div0.text();
                    String nguontruyen = temp0.split(";")[2];
                    String idTruyen = temp0.split(";")[0];

                    String metaKeywords =  document0.select("meta[name=keywords]").get(0).attr("content");
                    fname = metaKeywords.split(",")[2].trim();


                    siteUrl1 = siteUrl1 + nguontruyen + "&book=" + idTruyen;

                    //get from namesys.php
                    Document document = Jsoup.connect(siteUrl1).get();
                    Elements li = document.select("div");
                    for (int i = 0; i < li.size(); i++) {
                        String temp1 = li.get(i).text();
                        temp1  = temp1.split("@")[0];
                        temp1 = temp1.replace(" $","\n");
//                        temp1 = temp1.replace("$","\n");
                        temp1 = temp1.replace("$","");

                        buffer.append(temp1 + "\r\n");
                        break;
                    }

                } catch (IOException e) {
                    e.printStackTrace();

                }
            }
            else {
            }

            return buffer.toString();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            hideProgressDialog();
            if (s != null){
                resultText.setText(s);
            } else {
                resultText.setText("Error ?");
            }
        }
    }




    private void showProgessDialog(){
        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setMessage("Getting...");
        progressDialog.setCancelable(false);
        progressDialog.show();

    }

    private void hideProgressDialog(){
        if (progressDialog!= null || progressDialog.isShowing()){
            progressDialog.dismiss();
            progressDialog = null;
        }
    }

    private void createAndSaveFile(String fileName){
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory (Intent. CATEGORY_OPENABLE); intent.setType("text/plain");
        intent.putExtra(Intent. EXTRA_TITLE,fileName);
        startActivityForResult(intent, 1);
    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1)
        {
            if (resultCode == RESULT_OK)
            {
                try {
                    Uri uri = data.getData();
                    OutputStream outputstream = getContentResolver().openOutputStream(uri);
                    outputstream.write(fcontent.getBytes());
                    outputstream.close();
                    Toast.makeText(this, "File saved successfully", Toast.LENGTH_SHORT).
                            show();
                }
                catch (IOException e)
                {
                    Toast.makeText(this, "Fail to save file", Toast.LENGTH_SHORT).
                            show();
                }
            }
        }
        else
        {
            Toast.makeText(this,"File not saved", Toast.LENGTH_SHORT).show();
        }
    }

}
