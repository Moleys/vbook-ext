function execute() {
    return Response.success([
        {title: "全部", input:  "https://www.bookmobe.top/category/0/", script: "gen.js"}

    ]);
}