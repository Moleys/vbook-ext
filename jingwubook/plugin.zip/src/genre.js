function execute() {
    return Response.success([
       {title: "玄幻", input: "http://www.jingwubook.com/fenlei/1", script: "zen.js"},
       {title: "奇幻", input: "http://www.jingwubook.com/fenlei/2", script: "zen.js"},
       {title: "武侠", input: "http://www.jingwubook.com/fenlei/3", script: "zen.js"},
       {title: "仙侠", input: "http://www.jingwubook.com/fenlei/4", script: "zen.js"},
       {title: "都市", input: "http://www.jingwubook.com/fenlei/5", script: "zen.js"},
       {title: "军事", input: "http://www.jingwubook.com/fenlei/6", script: "zen.js"},
       {title: "历史", input: "http://www.jingwubook.com/fenlei/7", script: "zen.js"},
       {title: "游戏", input: "http://www.jingwubook.com/fenlei/8", script: "zen.js"},
       {title: "竞技", input: "http://www.jingwubook.com/fenlei/9", script: "zen.js"},
       {title: "科幻", input: "http://www.jingwubook.com/fenlei/10", script: "zen.js"},
       {title: "悬疑", input: "http://www.jingwubook.com/fenlei/11", script: "zen.js"},
       {title: "灵异", input: "http://www.jingwubook.com/fenlei/12", script: "zen.js"},
       {title: "其他", input: "http://www.jingwubook.com/fenlei/13", script: "zen.js"},
       {title: "古代", input: "http://www.jingwubook.com/fenlei/14", script: "zen.js"},
       {title: "仙侠", input: "http://www.jingwubook.com/fenlei/15", script: "zen.js"},
       {title: "现代", input: "http://www.jingwubook.com/fenlei/16", script: "zen.js"},
       {title: "浪漫", input: "http://www.jingwubook.com/fenlei/17", script: "zen.js"},
       {title: "玄幻", input: "http://www.jingwubook.com/fenlei/18", script: "zen.js"},
       {title: "悬疑", input: "http://www.jingwubook.com/fenlei/19", script: "zen.js"},
       {title: "科幻", input: "http://www.jingwubook.com/fenlei/20", script: "zen.js"},
       {title: "游戏", input: "http://www.jingwubook.com/fenlei/21", script: "zen.js"},
       {title: "BL", input: "http://www.jingwubook.com/fenlei/22", script: "zen.js"},
       {title: "GL", input: "http://www.jingwubook.com/fenlei/23", script: "zen.js"},
       {title: "二次", input: "http://www.jingwubook.com/fenlei/24", script: "zen.js"}

    ]);
}