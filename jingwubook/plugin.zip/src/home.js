function execute() {
    return Response.success([
        {title: "首页", input: "http://www.jingwubook.com/", script: "gen.js"},
       {title: "玄幻", input: "http://www.jingwubook.com/fenlei/1/1/", script: "gen.js"},
       {title: "奇幻", input: "http://www.jingwubook.com/fenlei/2/1/", script: "gen.js"},
       {title: "武侠", input: "http://www.jingwubook.com/fenlei/3/1/", script: "gen.js"},
       {title: "仙侠", input: "http://www.jingwubook.com/fenlei/4/1/", script: "gen.js"},
       {title: "都市", input: "http://www.jingwubook.com/fenlei/5/1/", script: "gen.js"},
       {title: "军事", input: "http://www.jingwubook.com/fenlei/6/1/", script: "gen.js"},
       {title: "历史", input: "http://www.jingwubook.com/fenlei/7/1/", script: "gen.js"},
       {title: "游戏", input: "http://www.jingwubook.com/fenlei/8/1/", script: "gen.js"},
       {title: "竞技", input: "http://www.jingwubook.com/fenlei/9/1/", script: "gen.js"},
       {title: "科幻", input: "http://www.jingwubook.com/fenlei/10/1/", script: "gen.js"},
       {title: "悬疑", input: "http://www.jingwubook.com/fenlei/11/1/", script: "gen.js"},
       {title: "灵异", input: "http://www.jingwubook.com/fenlei/12/1/", script: "gen.js"},
       {title: "其他", input: "http://www.jingwubook.com/fenlei/13/1/", script: "gen.js"},
       {title: "古代", input: "http://www.jingwubook.com/fenlei/14/1/", script: "gen.js"},
       {title: "仙侠", input: "http://www.jingwubook.com/fenlei/15/1/", script: "gen.js"},
       {title: "现代", input: "http://www.jingwubook.com/fenlei/16/1/", script: "gen.js"},
       {title: "浪漫", input: "http://www.jingwubook.com/fenlei/17/1/", script: "gen.js"},
       {title: "玄幻", input: "http://www.jingwubook.com/fenlei/18/1/", script: "gen.js"},
       {title: "悬疑", input: "http://www.jingwubook.com/fenlei/19/1/", script: "gen.js"},
       {title: "科幻", input: "http://www.jingwubook.com/fenlei/20/1/", script: "gen.js"},
       {title: "游戏", input: "http://www.jingwubook.com/fenlei/21/1/", script: "gen.js"},
       {title: "BL", input: "http://www.jingwubook.com/fenlei/22/1/", script: "gen.js"},
       {title: "GL", input: "http://www.jingwubook.com/fenlei/23/1/", script: "gen.js"},
       {title: "二次", input: "http://www.jingwubook.com/fenlei/24/1/", script: "gen.js"}

    ]);
}