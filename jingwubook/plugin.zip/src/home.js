function execute() {
    return Response.success([
        {title: "首页", input: "http://www.jingwubook.com/", script: "gen.js"}
    ]);
}