function execute() {
    return Response.success([
        {title: "言情", input:  "https://www.bijibaba.com/category/2/", script: "gen.js"},
        {title: "耽美", input:  "https://www.bijibaba.com/category/1/", script: "gen.js"},
        {title: "高辣", input:  "https://www.bijibaba.com/category/3/", script: "gen.js"},
        {title: "百合", input:  "https://www.bijibaba.com/category/4/", script: "gen.js"},
        {title: "科幻", input:  "https://www.bijibaba.com/category/17/", script: "gen.js"},
        {title: "玄幻", input:  "https://www.bijibaba.com/category/5/", script: "gen.js"},
        {title: "都市", input:  "https://www.bijibaba.com/category/15/", script: "gen.js"},
        {title: "高干", input:  "https://www.bijibaba.com/category/10/", script: "gen.js"},
        {title: "种田", input:  "https://www.bijibaba.com/category/8/", script: "gen.js"},
        {title: "腹黑", input:  "https://www.bijibaba.com/category/11/", script: "gen.js"},
        {title: "修真", input:  "https://www.bijibaba.com/category/9/", script: "gen.js"},
        {title: "穿越", input:  "https://www.bijibaba.com/category/16/", script: "gen.js"},
        {title: "网游", input:  "https://www.bijibaba.com/category/12/", script: "gen.js"},
        {title: "其他", input:  "https://www.bijibaba.com/category/14/", script: "gen.js"},
        {title: "灵异", input:  "https://www.bijibaba.com/category/24/", script: "gen.js"},
        {title: "二次元", input:  "https://www.bijibaba.com/category/23/", script: "gen.js"},
        {title: "武侠", input:  "https://www.bijibaba.com/category/20/", script: "gen.js"},
        {title: "历史", input:  "https://www.bijibaba.com/category/21/", script: "gen.js"},
        {title: "游戏", input:  "https://www.bijibaba.com/category/22/", script: "gen.js"},
        {title: "其它", input:  "https://www.bijibaba.com/category/7/", script: "gen.js"},
        {title: "军事", input:  "https://www.bijibaba.com/category/25/", script: "gen.js"}

    ]);
}