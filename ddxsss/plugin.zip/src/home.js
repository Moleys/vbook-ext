function execute() {
    return Response.success([
        {title: "首页", input: "https://www.ddxsss.com/", script: "gen.js"}
    ]);
}