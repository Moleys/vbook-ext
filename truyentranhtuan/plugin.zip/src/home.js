function execute() {
    return Response.success([
        {title: "Trang chủ", input: "http://truyentranhtuan.com/", script: "gen.js"},

    ]);
}