function execute() {
    return Response.success([
        {title: "都市激情", input:  "https://yazhouse8.com/article.php?cate=1", script: "gen2.js"},
        {title: "人妻交换", input:  "https://yazhouse8.com/article.php?cate=2", script: "gen2.js"},
        {title: "校园春色", input:  "https://yazhouse8.com/article.php?cate=3", script: "gen2.js"},
        {title: "家庭乱伦", input:  "https://yazhouse8.com/article.php?cate=4", script: "gen2.js"},
        {title: "情色笑话", input:  "https://yazhouse8.com/article.php?cate=5", script: "gen2.js"},
        {title: "性爱技巧", input:  "https://yazhouse8.com/article.php?cate=6", script: "gen2.js"},
        {title: "另类小说", input:  "https://yazhouse8.com/article.php?cate=7", script: "gen2.js"},
        {title: "纪实小说", input:  "https://yazhouse8.com/article.php?cate=9", script: "gen2.js"},
        {title: "武侠小说", input:  "https://yazhouse8.com/article.php?cate=10", script: "gen2.js"},
        {title: "虐待小说", input:  "https://yazhouse8.com/article.php?cate=11", script: "gen2.js"},
        {title: "丝袜小说", input:  "https://yazhouse8.com/l9kdK", script: "zen.js"},
        {title: "迷奸小说", input:  "https://yazhouse8.com/Ryuid", script: "zen.js"},
        {title: "调教小说", input:  "https://yazhouse8.com/KGl2i", script: "zen.js"},
        {title: "轮奸小说", input:  "https://yazhouse8.com/6pmJE", script: "zen.js"},
        {title: "兽交小说", input:  "https://yazhouse8.com/BmwSt", script: "zen.js"},
        {title: "露出小说", input:  "https://yazhouse8.com/thguq", script: "zen.js"},
        {title: "性奴小说", input:  "https://yazhouse8.com/McpCg", script: "zen.js"},
        {title: "巨乳小说", input:  "https://yazhouse8.com/sxUlc", script: "zen.js"},
        {title: "乱伦文章", input:  "https://yazhouse8.com/article.php?cate=8", script: "gen2.js"},
        {title: "两性话题", input:  "https://yazhouse8.com/article.php?cate=12", script: "gen2.js"}
    ]);
}