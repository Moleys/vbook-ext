function execute() {
    return Response.success([
        {title: "首页", input: "https://yazhouse8.com/article.php", script: "gen.js"},

    ]);
}