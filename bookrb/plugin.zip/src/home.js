function execute() {
    return Response.success([
        {title: "首页", input: "http://www.bookrbx.com/", script: "gen.js"},
        {title: "玄幻魔法", input: "http://www.bookrbx.com/xuanhuanxiaoshuo/", script: "gen.js"},
        {title: "仙侠修真", input: "http://www.bookrbx.com/xiuzhenxiaoshuo/", script: "gen.js"},
        {title: "都市青春", input: "http://www.bookrbx.com/dushixiaoshuo/", script: "gen.js"},
        {title: "历史穿越", input: "http://www.bookrbx.com/chuanyuexiaoshuo/", script: "gen.js"},
        {title: "女频言情", input: "http://www.bookrbx.com/wangyouxiaoshuo/", script: "gen.js"},
        {title: "恐怖灵异", input: "http://www.bookrbx.com/kehuanxiaoshuo/", script: "gen.js"},
        {title: "完本小说", input: "http://www.bookrbx.com/wanben/1_1", script: "gen.js"}

    ]);
}