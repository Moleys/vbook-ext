function execute(url) {
    let author = "Chu-Gong"
    return Response.success({
            name: "Solo Leveling",
            author: author,
            link: "https://sololeveling.ga",
            description: 'Theo chân Sung JinWoo trên hành trình từ "thợ săn kém cỏi" đến "thợ săn hạng S mạnh nhất thế giới".',
            cover: "https://i.imgur.com/8w6mwf7.jpg",
            detail: "Tác giả: "+author+"<br>Hoàn thành",
            host: "https://sololeveling.ga"
    });
}