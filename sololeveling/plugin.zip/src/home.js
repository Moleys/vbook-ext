function execute() {
    return Response.success([
        {title: "Trang chủ", input: "https://sololeveling.ga", script: "gen.js"}

    ]);
}