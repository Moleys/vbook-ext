function execute() {
    return Response.success([
       {title: "首页", input: "https://www.xinshuhaige.net/", script: "gen.js"},
       {title: "都市", input: "https://www.xinshuhaige.net/dushi/", script: "gen.js"},
       {title: "现言", input: "https://www.xinshuhaige.net/yanqing/", script: "gen.js"},
       {title: "古言", input: "https://www.xinshuhaige.net/guyan/", script: "gen.js"},
       {title: "青春", input: "https://www.xinshuhaige.net/qingchun/", script: "gen.js"},
       {title: "玄幻", input: "https://www.xinshuhaige.net/xuanhuan/", script: "gen.js"},
       {title: "武侠", input: "https://www.xinshuhaige.net/wuxia/", script: "gen.js"},
       {title: "悬疑", input: "https://www.xinshuhaige.net/xuanyi/", script: "gen.js"},
       {title: "历史", input: "https://www.xinshuhaige.net/lishi/", script: "gen.js"},
       {title: "游戏", input: "https://www.xinshuhaige.net/youxi/", script: "gen.js"},
       {title: "科幻", input: "https://www.xinshuhaige.net/kehuan/", script: "gen.js"},
       {title: "二次元", input: "https://www.xinshuhaige.net/erciyuan/", script: "gen.js"},
       {title: "新书", input: "https://www.xinshuhaige.net/xinshu/", script: "gen.js"}

    ]);
}