function execute() {
    return Response.success([


        {title: "日輕-最新更新", input:  "https://www.esjzone.cc/list-11", script: "gen.js"},
        {title: "日輕-最新上架", input:  "https://www.esjzone.cc/list-12", script: "gen.js"},
        {title: "日輕-最高評分", input:  "https://www.esjzone.cc/list-13", script: "gen.js"},
        {title: "日輕-最多觀看", input:  "https://www.esjzone.cc/list-14", script: "gen.js"},
        {title: "日輕-最多文章", input:  "https://www.esjzone.cc/list-15", script: "gen.js"},
        {title: "日輕-最多討論", input:  "https://www.esjzone.cc/list-16", script: "gen.js"},
        {title: "日輕-最多收藏", input:  "https://www.esjzone.cc/list-17", script: "gen.js"},
        {title: "日輕-最多字數", input:  "https://www.esjzone.cc/list-18", script: "gen.js"},
        {title: "韓輕-最新更新", input:  "https://www.esjzone.cc/list-21", script: "gen.js"},
        {title: "韓輕-最新上架", input:  "https://www.esjzone.cc/list-22", script: "gen.js"},
        {title: "韓輕-最高評分", input:  "https://www.esjzone.cc/list-23", script: "gen.js"},
        {title: "韓輕-最多觀看", input:  "https://www.esjzone.cc/list-24", script: "gen.js"},
        {title: "韓輕-最多文章", input:  "https://www.esjzone.cc/list-25", script: "gen.js"},
        {title: "韓輕-最多討論", input:  "https://www.esjzone.cc/list-26", script: "gen.js"},
        {title: "韓輕-最多收藏", input:  "https://www.esjzone.cc/list-27", script: "gen.js"},
        {title: "韓輕-最多字數", input:  "https://www.esjzone.cc/list-28", script: "gen.js"},

        {title: "原創-最新更新", input:  "https://www.esjzone.cc/list-31", script: "gen.js"},
        {title: "原創-最新上架", input:  "https://www.esjzone.cc/list-32", script: "gen.js"},
        {title: "原創-最高評分", input:  "https://www.esjzone.cc/list-33", script: "gen.js"},
        {title: "原創-最多觀看", input:  "https://www.esjzone.cc/list-34", script: "gen.js"},
        {title: "原創-最多文章", input:  "https://www.esjzone.cc/list-35", script: "gen.js"},
        {title: "原創-最多討論", input:  "https://www.esjzone.cc/list-36", script: "gen.js"},
        {title: "原創-最多收藏", input:  "https://www.esjzone.cc/list-37", script: "gen.js"},
        {title: "原創-最多字數", input:  "https://www.esjzone.cc/list-38", script: "gen.js"},



        {title: "重女", input:  "https://www.esjzone.cc/tags/重女", script: "gen.js"},
        {title: "后宫", input:  "https://www.esjzone.cc/tags/后宫", script: "gen.js"},
        {title: "恋爱", input:  "https://www.esjzone.cc/tags/恋爱", script: "gen.js"},
        {title: "奇幻", input:  "https://www.esjzone.cc/tags/奇幻", script: "gen.js"},
        {title: "病娇", input:  "https://www.esjzone.cc/tags/病娇", script: "gen.js"},
        {title: "修罗场", input:  "https://www.esjzone.cc/tags/修罗场", script: "gen.js"},
        {title: "异世界", input:  "https://www.esjzone.cc/tags/异世界", script: "gen.js"},
        {title: "幻想", input:  "https://www.esjzone.cc/tags/幻想", script: "gen.js"},


    ]);
}