function execute() {
    return Response.success([
        {title: "首页", input: "http://www.ranwen.la/", script: "gen.js"},
        {title: "玄幻小说", input: "http://www.ranwen.la/xuanhuanxiaoshuo/", script: "gen.js"},
        {title: "修真小说", input: "http://www.ranwen.la/xiuzhenxiaoshuo/", script: "gen.js"},
        {title: "都市小说", input: "http://www.ranwen.la/dushixiaoshuo/", script: "gen.js"},
        {title: "穿越小说", input: "http://www.ranwen.la/chuanyuexiaoshuo/", script: "gen.js"},
        {title: "网游小说", input: "http://www.ranwen.la/wangyouxiaoshuo/", script: "gen.js"},
        {title: "科幻小说", input: "http://www.ranwen.la/kehuanxiaoshuo/", script: "gen.js"},
        {title: "网游小说", input: "http://www.ranwen.la/yanqingxiaoshuo/", script: "gen.js"},
        {title: "科幻小说", input: "http://www.ranwen.la/tongrenxiaoshuo/", script: "gen.js"}

    ]);
}