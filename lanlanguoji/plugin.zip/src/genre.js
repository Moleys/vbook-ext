function execute() {
    return Response.success([
        {title: "玄幻小说", input: "http://www.lanlanguoji.com/fenlei/1", script: "zen.js"},
        {title: "奇幻小说", input: "http://www.lanlanguoji.com/fenlei/2", script: "zen.js"},
        {title: "武侠小说", input: "http://www.lanlanguoji.com/fenlei/3", script: "zen.js"},
        {title: "仙侠小说", input: "http://www.lanlanguoji.com/fenlei/4", script: "zen.js"},
        {title: "都市小说", input: "http://www.lanlanguoji.com/fenlei/5", script: "zen.js"},
        {title: "历史小说", input: "http://www.lanlanguoji.com/fenlei/6", script: "zen.js"},
        {title: "军事小说", input: "http://www.lanlanguoji.com/fenlei/7", script: "zen.js"},
        {title: "游戏小说", input: "http://www.lanlanguoji.com/fenlei/8", script: "zen.js"},
        {title: "体育小说", input: "http://www.lanlanguoji.com/fenlei/9", script: "zen.js"},
        {title: "科幻小说", input: "http://www.lanlanguoji.com/fenlei/10", script: "zen.js"},
        {title: "灵异小说", input: "http://www.lanlanguoji.com/fenlei/11", script: "zen.js"},
        {title: "古代小说", input: "http://www.lanlanguoji.com/fenlei/12", script: "zen.js"},
        {title: "现代小说", input: "http://www.lanlanguoji.com/fenlei/13", script: "zen.js"},
        {title: "玄幻小说", input: "http://www.lanlanguoji.com/fenlei/14", script: "zen.js"},
        {title: "仙侠小说", input: "http://www.lanlanguoji.com/fenlei/15", script: "zen.js"},
        {title: "浪漫小说", input: "http://www.lanlanguoji.com/fenlei/16", script: "zen.js"},
        {title: "游戏小说", input: "http://www.lanlanguoji.com/fenlei/17", script: "zen.js"},
        {title: "科幻小说", input: "http://www.lanlanguoji.com/fenlei/18", script: "zen.js"},
        {title: "悬疑小说", input: "http://www.lanlanguoji.com/fenlei/19", script: "zen.js"},
        {title: "二次小说", input: "http://www.lanlanguoji.com/fenlei/20", script: "zen.js"},
        {title: "其他小说", input: "http://www.lanlanguoji.com/fenlei/21", script: "zen.js"}
    ]);
}