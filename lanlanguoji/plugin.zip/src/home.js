function execute() {
    return Response.success([
        {title: "首页", input: "http://www.lanlanguoji.com/", script: "gen.js"},
        {title: "玄幻小说", input: "http://www.lanlanguoji.com/fenlei/1/1/", script: "gen.js"},
        {title: "奇幻小说", input: "http://www.lanlanguoji.com/fenlei/2/1/", script: "gen.js"},
        {title: "武侠小说", input: "http://www.lanlanguoji.com/fenlei/3/1/", script: "gen.js"},
        {title: "仙侠小说", input: "http://www.lanlanguoji.com/fenlei/4/1/", script: "gen.js"},
        {title: "都市小说", input: "http://www.lanlanguoji.com/fenlei/5/1/", script: "gen.js"},
        {title: "历史小说", input: "http://www.lanlanguoji.com/fenlei/6/1/", script: "gen.js"},
        {title: "军事小说", input: "http://www.lanlanguoji.com/fenlei/7/1/", script: "gen.js"},
        {title: "游戏小说", input: "http://www.lanlanguoji.com/fenlei/8/1/", script: "gen.js"},
        {title: "体育小说", input: "http://www.lanlanguoji.com/fenlei/9/1/", script: "gen.js"},
        {title: "科幻小说", input: "http://www.lanlanguoji.com/fenlei/10/1/", script: "gen.js"},
        {title: "灵异小说", input: "http://www.lanlanguoji.com/fenlei/11/1/", script: "gen.js"},
        {title: "古代小说", input: "http://www.lanlanguoji.com/fenlei/12/1/", script: "gen.js"},
        {title: "现代小说", input: "http://www.lanlanguoji.com/fenlei/13/1/", script: "gen.js"},
        {title: "玄幻小说", input: "http://www.lanlanguoji.com/fenlei/14/1/", script: "gen.js"},
        {title: "仙侠小说", input: "http://www.lanlanguoji.com/fenlei/15/1/", script: "gen.js"},
        {title: "浪漫小说", input: "http://www.lanlanguoji.com/fenlei/16/1/", script: "gen.js"},
        {title: "游戏小说", input: "http://www.lanlanguoji.com/fenlei/17/1/", script: "gen.js"},
        {title: "科幻小说", input: "http://www.lanlanguoji.com/fenlei/18/1/", script: "gen.js"},
        {title: "悬疑小说", input: "http://www.lanlanguoji.com/fenlei/19/1/", script: "gen.js"},
        {title: "二次小说", input: "http://www.lanlanguoji.com/fenlei/20/1/", script: "gen.js"},
        {title: "其他小说", input: "http://www.lanlanguoji.com/fenlei/21/1/", script: "gen.js"}

    ]);
}