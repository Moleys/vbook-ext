function execute() {
    return Response.success([
        {title: "首页", input: "http://www.lanlanguoji.com/", script: "gen.js"}

    ]);
}