function execute() {
    return Response.success([

      	{title: "鬼话", input:  "https://sjks88.com/Direct1/", script: "gen.js"},
      	{title: "情感", input:  "https://sjks88.com/Direct2/", script: "gen.js"},
      	{title: "玄幻", input:  "https://sjks88.com/xuanhuan/", script: "gen.js"},
      	{title: "奇幻", input:  "https://sjks88.com/Direct3/", script: "gen.js"},
      	{title: "商道", input:  "https://sjks88.com/Direct4/", script: "gen.js"},
      	{title: "军事", input:  "https://sjks88.com/Direct5/", script: "gen.js"},
      	{title: "历史", input:  "https://sjks88.com/Direct6/", script: "gen.js"},
      	{title: "传记", input:  "https://sjks88.com/zhuanji/", script: "gen.js"},
      	{title: "言情", input:  "https://sjks88.com/Direct7/", script: "gen.js"},
      	{title: "都市", input:  "https://sjks88.com/ds/", script: "gen.js"},
      	{title: "耽美", input:  "https://sjks88.com/danmei/", script: "gen.js"},
      	{title: "同人", input:  "https://sjks88.com/erciyuan/", script: "gen.js"},
      	{title: "武侠", input:  "https://sjks88.com/wuxia/", script: "gen.js"},
      	{title: "修真", input:  "https://sjks88.com/xiuzhen/", script: "gen.js"},
      	{title: "官场", input:  "https://sjks88.com/guanchang/", script: "gen.js"},
      	{title: "网游", input:  "https://sjks88.com/wangyou/", script: "gen.js"},
      	{title: "科幻", input:  "https://sjks88.com/kehuan/", script: "gen.js"},
      	{title: "穿越", input:  "https://sjks88.com/chuanyue/", script: "gen.js"},
      	{title: "悬疑", input:  "https://sjks88.com/Suspense/", script: "gen.js"},
      	{title: "纪实", input:  "https://sjks88.com/jishi/", script: "gen.js"},
      	{title: "精品", input:  "https://sjks88.com/xiaoshuo/", script: "gen.js"},
      	{title: "乡土", input:  "https://sjks88.com/xt/", script: "gen.js"},
      	{title: "排行", input:  "https://sjks88.com/ranking/", script: "gen.js"}
    ]);
}