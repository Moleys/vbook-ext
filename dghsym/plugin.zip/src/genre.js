function execute() {
    return Response.success([
        {title: "全部分类", input:  "https://www.dghsym.com/sort/", script: "zen.js"},
        {title: "玄幻魔法", input:  "https://www.dghsym.com/sort/1/", script: "zen.js"},
        {title: "武侠修真", input:  "https://www.dghsym.com/sort/2/", script: "zen.js"},
        {title: "都市言情", input:  "https://www.dghsym.com/sort/3/", script: "zen.js"},
        {title: "历史军事", input:  "https://www.dghsym.com/sort/4/", script: "zen.js"},
        {title: "科幻灵异", input:  "https://www.dghsym.com/sort/5/", script: "zen.js"},
        {title: "游戏竞技", input:  "https://www.dghsym.com/sort/6/", script: "zen.js"},
        {title: "女生耽美", input:  "https://www.dghsym.com/sort/7/", script: "zen.js"},
        {title: "其他类型", input:  "https://www.dghsym.com/sort/8/", script: "zen.js"}

    ]);
}