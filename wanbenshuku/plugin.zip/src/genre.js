function execute() {
    return Response.success([
        {title: "玄幻", input: "https://www.wanbenshuku.com/sort/1_", script: "zen.js"},
        {title: "武侠", input: "https://www.wanbenshuku.com/sort/2_", script: "zen.js"},
        {title: "都市", input: "https://www.wanbenshuku.com/sort/3_", script: "zen.js"},
        {title: "言情", input: "https://www.wanbenshuku.com/sort/4_", script: "zen.js"},
        {title: "历史", input: "https://www.wanbenshuku.com/sort/5_", script: "zen.js"},
        {title: "科幻", input: "https://www.wanbenshuku.com/sort/6_", script: "zen.js"},
        {title: "恐怖", input: "https://www.wanbenshuku.com/sort/7_", script: "zen.js"},
        {title: "其他", input: "https://www.wanbenshuku.com/sort/8_", script: "zen.js"},
        {title: "穿越", input: "https://www.wanbenshuku.com/sort/9_", script: "zen.js"},
        {title: "游戏", input: "https://www.wanbenshuku.com/sort/10_", script: "zen.js"},
        {title: "轻小说", input: "https://www.wanbenshuku.com/sort/11_", script: "zen.js"},
        {title: "古言", input: "https://www.wanbenshuku.com/sort/12_", script: "zen.js"},
        {title: "二次元", input: "https://www.wanbenshuku.com/sort/13_", script: "zen.js"},
        {title: "青春", input: "https://www.wanbenshuku.com/sort/14_", script: "zen.js"},
        {title: "同人", input: "https://www.wanbenshuku.com/sort/15_", script: "zen.js"},
        {title: "GLBL", input: "https://www.wanbenshuku.com/sort/16_", script: "zen.js"}

    ]);
}