function execute() {
    return Response.success([
        {title: "Browser", input: "https://koushoku.org", script: "gen.js"},
    ]);
}