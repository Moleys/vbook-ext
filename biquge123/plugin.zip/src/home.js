function execute() {
    return Response.success([
        {title: "首页", input: "https://www.biquge123.cc/", script: "gen.js"}

    ]);
}