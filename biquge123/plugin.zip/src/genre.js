function execute() {
    return Response.success([
        {title: "玄幻奇幻", input:  "https://www.biquge123.cc/xs1/", script: "zen.js"},
        {title: "武侠仙侠", input:  "https://www.biquge123.cc/xs2/", script: "zen.js"},
        {title: "都市言情", input:  "https://www.biquge123.cc/xs3/", script: "zen.js"},
        {title: "历史军事", input:  "https://www.biquge123.cc/xs4/", script: "zen.js"},
        {title: "科幻灵异", input:  "https://www.biquge123.cc/xs5/", script: "zen.js"},
        {title: "网游竞技", input:  "https://www.biquge123.cc/xs6/", script: "zen.js"},
        {title: "女生频道", input:  "https://www.biquge123.cc/xs7/", script: "zen.js"}

    ]);
}