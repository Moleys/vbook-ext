function execute() {
    return Response.success([
        {title: "现代耽美", input:  "http://www.fuxsb.com/xiandai/", script: "gen.js"},
        {title: "古代耽美", input:  "http://www.fuxsb.com/gudai/", script: "gen.js"},
        {title: "穿越重生", input:  "http://www.fuxsb.com/chuanyue/", script: "gen.js"},
        {title: "玄幻灵异", input:  "http://www.fuxsb.com/qihuan/", script: "gen.js"},
        {title: "网游竞技", input:  "http://www.fuxsb.com/wangyou/", script: "gen.js"},
        {title: "同人耽美", input:  "http://www.fuxsb.com/tongren/", script: "gen.js"},
        {title: "G L 百合", input:  "http://www.fuxsb.com/baihe/", script: "gen.js"},
    ]);
}