function execute() {
    return Response.success([
        {title: "首页", input: "https://www.qmxs123.com/", script: "gen.js"}
    ]);
}