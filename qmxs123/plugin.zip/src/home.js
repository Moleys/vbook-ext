function execute() {
    return Response.success([
        {title: "首页", input: "https://www.qmxs123.com/", script: "gen.js"},
        {title: "玄幻", input: "https://www.qmxs123.com/xuanhuan/", script: "gen.js"},
        {title: "武侠", input: "https://www.qmxs123.com/wuxia/", script: "gen.js"},
        {title: "都市", input: "https://www.qmxs123.com/dushi/", script: "gen.js"},
        {title: "历史", input: "https://www.qmxs123.com/lishi/", script: "gen.js"},
        {title: "网游", input: "https://www.qmxs123.com/wangyou/", script: "gen.js"},
        {title: "科幻", input: "https://www.qmxs123.com/kehuan/", script: "gen.js"},
        {title: "女生", input: "https://www.qmxs123.com/mm/", script: "gen.js"},
        {title: "完本", input: "https://www.qmxs123.com/finish/", script: "gen.js"},
        {title: "排行榜", input: "https://www.qmxs123.com/top/", script: "gen.js"}

    ]);
}