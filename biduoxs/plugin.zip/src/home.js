function execute() {
    return Response.success([
        {title: "首页", input: "https://www.biduoxs.com/", script: "gen.js"},
        {title: "玄幻魔法", input: "https://www.biduoxs.com/book_1_1/", script: "gen.js"},
        {title: "武侠修真", input: "https://www.biduoxs.com/book_2_1/", script: "gen.js"},
        {title: "都市言情", input: "https://www.biduoxs.com/book_3_1/", script: "gen.js"},
        {title: "历史军事", input: "https://www.biduoxs.com/book_4_1/", script: "gen.js"},
        {title: "网游动漫", input: "https://www.biduoxs.com/book_6_1/", script: "gen.js"},
        {title: "科幻小说", input: "https://www.biduoxs.com/book_7_1/", script: "gen.js"},
        {title: "恐怖灵异", input: "https://www.biduoxs.com/book_8_1/", script: "gen.js"},
        {title: "其他小说", input: "https://www.biduoxs.com/book_10_1/", script: "gen.js"}

    ]);
}