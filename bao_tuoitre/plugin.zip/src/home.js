function execute() {
    return Response.success([
        {title: "Chuyên mục", input:  "list", script: "gen.js"},

    ]);
}