function execute() {
    return Response.success([
        {title: "首页", input: "http://www.biqu5200.net/", script: "gen.js"},
        {title: "玄幻小说", input: "http://www.biqu5200.net/xuanhuanxiaoshuo/", script: "gen.js"},
        {title: "修真小说", input: "http://www.biqu5200.net/xiuzhenxiaoshuo/", script: "gen.js"},
        {title: "都市小说", input: "http://www.biqu5200.net/dushixiaoshuo/", script: "gen.js"},
        {title: "穿越小说", input: "http://www.biqu5200.net/chuanyuexiaoshuo/", script: "gen.js"},
        {title: "网游小说", input: "http://www.biqu5200.net/wangyouxiaoshuo/", script: "gen.js"},
        {title: "科幻小说", input: "http://www.biqu5200.net/kehuanxiaoshuo/", script: "gen.js"},
        {title: "网游小说", input: "http://www.biqu5200.net/yanqingxiaoshuo/", script: "gen.js"},
        {title: "科幻小说", input: "http://www.biqu5200.net/tongrenxiaoshuo/", script: "gen.js"}

    ]);
}