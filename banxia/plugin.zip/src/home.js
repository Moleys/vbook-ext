function execute() {
    return Response.success([
        {title: "玄幻", input:  "https://www.banxia.tv/bxsort/xuanhuan", script: "gen.js"},
        {title: "武俠", input:  "https://www.banxia.tv/bxsort/wuxia", script: "gen.js"},
        {title: "都市", input:  "https://www.banxia.tv/bxsort/dushi", script: "gen.js"},
        {title: "歷史", input:  "https://www.banxia.tv/bxsort/lishi", script: "gen.js"},
        {title: "穿越", input:  "https://www.banxia.tv/bxsort/chuanyue", script: "gen.js"},
        {title: "遊戲", input:  "https://www.banxia.tv/bxsort/youxi", script: "gen.js"},
        {title: "科幻", input:  "https://www.banxia.tv/bxsort/kehuan", script: "gen.js"},
        {title: "同人", input:  "https://www.banxia.tv/bxsort/tongren", script: "gen.js"},
        {title: "女生", input:  "https://www.banxia.tv/bxsort/nvsheng", script: "gen.js"},
        {title: "社會", input:  "https://www.banxia.tv/bxsort/shehui", script: "gen.js"},
        {title: "綜合", input:  "https://www.banxia.tv/bxsort/zonghe", script: "gen.js"}
    ]);
}