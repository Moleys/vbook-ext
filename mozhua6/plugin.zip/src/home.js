function execute() {
    return Response.success([
        {title: "穿越小说", input: "https://www.mozhua6.com/forum.php?mod=forumdisplay&fid=694", script: "gen.js"},
        {title: "言情小说", input: "https://www.mozhua6.com/forum.php?mod=forumdisplay&fid=695", script: "gen.js"},
        {title: "其它", input: "https://www.mozhua6.com/forum.php?mod=forumdisplay&fid=725", script: "gen.js"}

    ]);
}