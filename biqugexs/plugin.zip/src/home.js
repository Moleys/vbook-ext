function execute() {
    return Response.success([
        {title: "首页", input: "http://www.biqugexs.com/", script: "gen.js"},
        {title: "玄幻小说", input: "http://www.biqugexs.com/xuanhuan/", script: "gen.js"},
        {title: "修真小说", input: "http://www.biqugexs.com/xiuzhen/", script: "gen.js"},
        {title: "都市小说", input: "http://www.biqugexs.com/dushi/", script: "gen.js"},
        {title: "历史小说", input: "http://www.biqugexs.com/lishi/", script: "gen.js"},
        {title: "网游小说", input: "http://www.biqugexs.com/wangyou/", script: "gen.js"},
        {title: "科幻小说", input: "http://www.biqugexs.com/kehuan/", script: "gen.js"},
        {title: "言情小说", input: "http://www.biqugexs.com/yanqing/", script: "gen.js"},
        {title: "其他小说", input: "http://www.biqugexs.com/qita/", script: "gen.js"},
        {title: "全本小说", input: "http://www.biqugexs.com/quanben/", script: "gen.js"},
        {title: "临时书架", input: "http://www.biqugexs.com/bookcase.html", script: "gen.js"}

    ]);
}