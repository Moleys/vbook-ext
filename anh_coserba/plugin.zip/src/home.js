function execute() {
    return Response.success([
        {title: "妹子鉴赏", input:  "https://www.coserba.net/mzjs", script: "gen.js"},
        {title: "ACG", input:  "https://www.coserba.net/acg", script: "gen.js"}

    ]);
}