function execute(url) {

    const data = [];

    data.push({
        name: "1",
        url: url,
        host: "http://www.mm4000.com/meinv/"
    })


    return Response.success(data);
}
