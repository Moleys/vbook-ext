function execute() {
    return Response.success([
        {title: "书架", input: "0", script: "gen.js"}
    ]);
}