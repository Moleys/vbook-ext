let config_host = "http://localhost:1122";
if (typeof host !== "undefined") {
    config_host = host
}