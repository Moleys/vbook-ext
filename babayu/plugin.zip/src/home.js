function execute() {
    return Response.success([
        { title: "小说书库", input: "all.html", script: "gen.js" },
    ]);
}