function execute() {
    return Response.success([
        {title: "玄幻奇幻", input:  "book_42.html", script: "source.js"},
        {title: "武侠修真", input:  "book_43.html", script: "source.js"},
        {title: "都市异能", input:  "book_44.html", script: "source.js"},
        {title: "历史军事", input:  "book_45.html", script: "source.js"},
        {title: "网游竞技", input:  "book_46.html", script: "source.js"},
        {title: "科幻灭世", input:  "book_47.html", script: "source.js"},
        {title: "惊悚悬疑", input:  "book_49.html", script: "source.js"},
        {title: "轻小说", input:  "book_52.html", script: "source.js"},
        {title: "女生频道", input:  "book_48.html", script: "source.js"},
    ]);
}