function execute() {
    return Response.success([
        {title: "首页", input: "http://www.ttzw.com/", script: "gen.js"},
        {title: "玄幻奇幻", input:  "http://www.ttzw.com/class/1/1.html", script: "gen.js"},
        {title: "武侠仙侠", input:  "http://www.ttzw.com/class/2/1.html", script: "gen.js"},
        {title: "都市言情", input:  "http://www.ttzw.com/class/3/1.html", script: "gen.js"},
        {title: "历史军事", input:  "http://www.ttzw.com/class/4/1.html", script: "gen.js"},
        {title: "科幻灵异", input:  "http://www.ttzw.com/class/5/1.html", script: "gen.js"},
        {title: "网游竞技", input:  "http://www.ttzw.com/class/6/1.html", script: "gen.js"},
        {title: "女生频道", input:  "http://www.ttzw.com/class/7/1.html", script: "gen.js"}

    ]);
}