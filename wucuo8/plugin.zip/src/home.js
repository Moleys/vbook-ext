function execute() {
    return Response.success([
        {title: "玄幻", input:  "https://www.wucuo8.com/xuanhuan/", script: "gen.js"},
        {title: "奇幻", input:  "https://www.wucuo8.com/qihuan/", script: "gen.js"},
        {title: "武侠", input:  "https://www.wucuo8.com/wuxia/", script: "gen.js"},
        {title: "仙侠", input:  "https://www.wucuo8.com/xianxia/", script: "gen.js"},
        {title: "都市", input:  "https://www.wucuo8.com/dushi/", script: "gen.js"},
        {title: "历史", input:  "https://www.wucuo8.com/lishi/", script: "gen.js"},
        {title: "军事", input:  "https://www.wucuo8.com/junshi/", script: "gen.js"},
        {title: "科幻", input:  "https://www.wucuo8.com/kehuan/", script: "gen.js"},
        {title: "悬疑", input:  "https://www.wucuo8.com/xuanyi/", script: "gen.js"},
        {title: "体育", input:  "https://www.wucuo8.com/tiyu/", script: "gen.js"},
        {title: "游戏", input:  "https://www.wucuo8.com/youxi/", script: "gen.js"},
        {title: "二次元", input:  "https://www.wucuo8.com/erciyuan/", script: "gen.js"}


    ]);
}