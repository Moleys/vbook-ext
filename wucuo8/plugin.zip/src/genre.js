function execute() {
    return Response.success([
        {title: "2022完结小说", input:  "https://www.wucuo8.com/2022/", script: "gen.js"},
        {title: "2021完结小说", input:  "https://www.wucuo8.com/2021/", script: "gen.js"},
        {title: "2020完结小说", input:  "https://www.wucuo8.com/2020/", script: "gen.js"},
        {title: "2019完结小说", input:  "https://www.wucuo8.com/2019/", script: "gen.js"},
        {title: "2018完结小说", input:  "https://www.wucuo8.com/2018/", script: "gen.js"},
        {title: "2017完结小说", input:  "https://www.wucuo8.com/2017/", script: "gen.js"},
        {title: "2016完结小说", input:  "https://www.wucuo8.com/2016/", script: "gen.js"},
        {title: "2015完结小说", input:  "https://www.wucuo8.com/2015/", script: "gen.js"},
        {title: "2014完结小说", input:  "https://www.wucuo8.com/2014/", script: "gen.js"},
        {title: "周下载排行", input:  "https://www.wucuo8.com/zhoupaihang/", script: "gen.js"},
        {title: "月下载排行", input:  "https://www.wucuo8.com/yuepaihang/", script: "gen.js"},
        {title: "总下载排行", input:  "https://www.wucuo8.com/zongpaihang/", script: "gen.js"},
        {title: "字数排行", input:  "https://www.wucuo8.com/zishu/", script: "gen.js"},
        {title: "经典小说推荐", input:  "https://www.wucuo8.com/jingdian/", script: "gen.js"},
        {title: "热门小说推荐", input:  "https://www.wucuo8.com/remen/", script: "gen.js"}


    ]);
}