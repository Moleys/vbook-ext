function execute() {
    return Response.success([
		{title: "首页", input: "https://www.xinwanben.com/", script: "gen.js"},
        {title: "玄幻", input: "https://www.xinwanben.com/fenlei/1/1/", script: "gen.js"},
        {title: "奇幻", input: "https://www.xinwanben.com/fenlei/2/1/", script: "gen.js"},
        {title: "武侠", input: "https://www.xinwanben.com/fenlei/3/1/", script: "gen.js"},
        {title: "仙侠", input: "https://www.xinwanben.com/fenlei/4/1/", script: "gen.js"},
        {title: "都市", input: "https://www.xinwanben.com/fenlei/5/1/", script: "gen.js"},
        {title: "军事", input: "https://www.xinwanben.com/fenlei/6/1/", script: "gen.js"},
        {title: "历史", input: "https://www.xinwanben.com/fenlei/7/1/", script: "gen.js"},
        {title: "游戏", input: "https://www.xinwanben.com/fenlei/8/1/", script: "gen.js"},
        {title: "科幻", input: "https://www.xinwanben.com/fenlei/10/1/", script: "gen.js"},
        {title: "二次元", input: "https://www.xinwanben.com/fenlei/24/1/", script: "gen.js"}

    ]);
}