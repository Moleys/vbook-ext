function execute() {
    return Response.success([
        {
            "input": "https://www.po18gv.vip/list/1.html",
            "title": "都市小说",
            "script": "gen.js"
        },
        {
            "input": "https://www.po18gv.vip/list/2.html",
            "title": "浓情小说",
            "script": "gen.js"
        },
        {
            "input": "https://www.po18gv.vip/list/3.html",
            "title": "言情小说",
            "script": "gen.js"
        },
        {
            "input": "https://www.po18gv.vip/list/4.html",
            "title": "校园小说",
            "script": "gen.js"
        },
        {
            "input": "https://www.po18gv.vip/list/5.html",
            "title": "武侠小说",
            "script": "gen.js"
        },
        {
            "input": "https://www.po18gv.vip/list/6.html",
            "title": "玄幻小说",
            "script": "gen.js"
        },
        {
            "input": "https://www.po18gv.vip/list/7.html",
            "title": "穿越小说",
            "script": "gen.js"
        },
        {
            "input": "https://www.po18gv.vip/list/8.html",
            "title": "惊悚小说",
            "script": "gen.js"
        },
        {
            "input": "https://www.po18gv.vip/list/9.html",
            "title": "悬疑小说",
            "script": "gen.js"
        },
        {
            "input": "https://www.po18gv.vip/list/10.html",
            "title": "重生小说",
            "script": "gen.js"
        },
        {
            "input": "https://www.po18gv.vip/list/11.html",
            "title": "历史小说",
            "script": "gen.js"
        },
        {
            "input": "https://www.po18gv.vip/list/12.html",
            "title": "其他小说",
            "script": "gen.js"
        }
    ]);
}