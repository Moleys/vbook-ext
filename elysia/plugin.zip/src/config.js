let BASE_URL = "https://mnz.nhimmeo.cf";
if (typeof host !== "undefined") {
    BASE_URL = host
}

function re_cover(link) {
    return link.replace("http://","https://").replace("https://","https://i0.wp.com/")



}