let BASE_URL = "https://cwm.elysia.rip";
if (typeof host !== "undefined") {
    BASE_URL = host
}

function re_cover(link) {
    return link.replace("http://","https://").replace("https://","https://i0.wp.com/")



}