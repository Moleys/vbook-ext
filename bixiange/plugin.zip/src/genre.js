function execute() {
    return Response.success([
       {title: "都市言情", input: "http://www.bixiange.top/dsyq/", script: "zen.js"},
       {title: "武侠修真", input: "http://www.bixiange.top/wxxz/", script: "zen.js"},
       {title: "玄幻奇幻", input: "http://www.bixiange.top/xhqh/", script: "zen.js"},
       {title: "穿越架空", input: "http://www.bixiange.top/cyjk/", script: "zen.js"},
       {title: "科幻竞技", input: "http://www.bixiange.top/khjj/", script: "zen.js"},
       {title: "鬼话悬疑", input: "http://www.bixiange.top/ghxy/", script: "zen.js"},
       {title: "军事历史", input: "http://www.bixiange.top/jsls/", script: "zen.js"},
       {title: "官场商战", input: "http://www.bixiange.top/guanchang/", script: "zen.js"},
       {title: "乡土风情", input: "http://www.bixiange.top/xtfq/", script: "zen.js"},
       {title: "耽美小说", input: "http://www.bixiange.top/dmtr/", script: "zen.js"},
       {title: "同人小说", input: "http://www.bixiange.top/trxs/", script: "zen.js"},
       {title: "精品小说", input: "http://www.bixiange.top/jqxs/", script: "zen.js"},
       {title: "排行榜", input: "http://www.bixiange.top/sort/", script: "zen.js"}

    ]);
}