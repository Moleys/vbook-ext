function execute() {
    return Response.success([
        {title: "首页", input: "http://www.bixiange.top/", script: "gen.js"},
       {title: "都市言情", input: "http://www.bixiange.top/dsyq/", script: "gen.js"},
       {title: "武侠修真", input: "http://www.bixiange.top/wxxz/", script: "gen.js"},
       {title: "玄幻奇幻", input: "http://www.bixiange.top/xhqh/", script: "gen.js"},
       {title: "穿越架空", input: "http://www.bixiange.top/cyjk/", script: "gen.js"},
       {title: "科幻竞技", input: "http://www.bixiange.top/khjj/", script: "gen.js"},
       {title: "鬼话悬疑", input: "http://www.bixiange.top/ghxy/", script: "gen.js"},
       {title: "军事历史", input: "http://www.bixiange.top/jsls/", script: "gen.js"},
       {title: "官场商战", input: "http://www.bixiange.top/guanchang/", script: "gen.js"},
       {title: "乡土风情", input: "http://www.bixiange.top/xtfq/", script: "gen.js"},
       {title: "耽美小说", input: "http://www.bixiange.top/dmtr/", script: "gen.js"},
       {title: "同人小说", input: "http://www.bixiange.top/trxs/", script: "gen.js"},
       {title: "精品小说", input: "http://www.bixiange.top/jqxs/", script: "gen.js"},
       {title: "排行榜", input: "http://www.bixiange.top/sort/", script: "gen.js"}

    ]);
}