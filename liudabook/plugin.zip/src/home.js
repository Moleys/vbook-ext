function execute() {
    return Response.success([
        {title: "青春言情", input: "https://www.liudabook.com/thread.php?fid-12", script: "gen.js"},
        {title: "耽美同人", input: "https://www.liudabook.com/thread.php?fid-59", script: "gen.js"},
        {title: "武侠魔幻", input: "https://www.liudabook.com/thread.php?fid-101", script: "gen.js"},
        {title: "恐怖侦破", input: "https://www.liudabook.com/thread.php?fid-15", script: "gen.js"},
        {title: "军事历史", input: "https://www.liudabook.com/thread.php?fid-16", script: "gen.js"},
        {title: "中外文学", input: "https://www.liudabook.com/thread.php?fid-28", script: "gen.js"},
        {title: "学习励志", input: "https://www.liudabook.com/thread.php?fid-17", script: "gen.js"},
        {title: "生活休闲", input: "https://www.liudabook.com/thread.php?fid-58", script: "gen.js"},
        
    ]);
}