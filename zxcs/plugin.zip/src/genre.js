function execute() {
    return Response.success([
        {title: "都市·娱乐", input:  "http://zxcs.me/sort/23", script: "gen.js"},
        {title: "武侠·仙侠", input:  "http://zxcs.me/sort/25", script: "gen.js"},
        {title: "精校武侠", input:  "http://zxcs.me/sort/36", script: "gen.js"},
        {title: "精校仙侠", input:  "http://zxcs.me/sort/37", script: "gen.js"},
        {title: "奇幻·玄幻", input:  "http://zxcs.me/sort/26", script: "gen.js"},
        {title: "精校奇幻", input:  "http://zxcs.me/sort/38", script: "gen.js"},
        {title: "精校玄幻", input:  "http://zxcs.me/sort/39", script: "gen.js"},
        {title: "科幻·灵异", input:  "http://zxcs.me/sort/27", script: "gen.js"},
        {title: "精校科幻", input:  "http://zxcs.me/sort/40", script: "gen.js"},
        {title: "精校灵异", input:  "http://zxcs.me/sort/41", script: "gen.js"},
        {title: "历史·军事", input:  "http://zxcs.me/sort/28", script: "gen.js"},
        {title: "精校历史", input:  "http://zxcs.me/sort/42", script: "gen.js"},
        {title: "精校军事", input:  "http://zxcs.me/sort/43", script: "gen.js"},
        {title: "竞技·游戏", input:  "http://zxcs.me/sort/29", script: "gen.js"},
        {title: "精校竞技", input:  "http://zxcs.me/sort/44", script: "gen.js"},
        {title: "精校游戏", input:  "http://zxcs.me/sort/45", script: "gen.js"},
        {title: "二次元", input:  "http://zxcs.me/sort/55", script: "gen.js"}



    ]);
}