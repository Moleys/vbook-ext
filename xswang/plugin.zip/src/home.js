function execute() {
    return Response.success([
        {title: "首页", input: "https://www.xswang.com/", script: "gen.js"},
        {title: "玄幻小说", input: "https://www.xswang.com/class/1/1.html", script: "gen.js"},
        {title: "修真小说", input: "https://www.xswang.com/class/2/1.html", script: "gen.js"},
        {title: "都市小说", input: "https://www.xswang.com/class/3/1.html", script: "gen.js"},
        {title: "历史小说", input: "https://www.xswang.com/class/4/1.html", script: "gen.js"},
        {title: "网游小说", input: "https://www.xswang.com/class/5/1.html", script: "gen.js"},
        {title: "科幻小说", input: "https://www.xswang.com/class/6/1.html", script: "gen.js"},
        {title: "其它小说", input: "https://www.xswang.com/class/7/1.html", script: "gen.js"},
        {title: "完本小说", input: "https://www.xswang.com/quanben/0/index.html", script: "gen.js"}

    ]);
}