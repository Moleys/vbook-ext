function execute() {
    return Response.success([
        {title: "全部", input: "https://m.xswang.com/class/0/", script: "gen.js"},
        {title: "玄幻", input: "https://m.xswang.com/class/1/", script: "gen.js"},
        {title: "修真", input: "https://m.xswang.com/class/2/", script: "gen.js"},
        {title: "都市", input: "https://m.xswang.com/class/3/", script: "gen.js"},
        {title: "历史", input: "https://m.xswang.com/class/4/", script: "gen.js"},
        {title: "网游", input: "https://m.xswang.com/class/5/", script: "gen.js"},
        {title: "科幻", input: "https://m.xswang.com/class/6/", script: "gen.js"},
        {title: "其它", input: "https://m.xswang.com/class/7/", script: "gen.js"},
    ]);
}