function execute() {
    return Response.success([
        {title: "全部", input:  "https://www.sosadfun.org/category/0/", script: "gen.js"}

    ]);
}