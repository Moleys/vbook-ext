function execute() {
    return Response.success([
        {title: "全部", input:  "https://www.wanben.org/all/0_lastupdate_0_0_", script: "zen.js"},
        {title: "玄幻", input:  "https://www.wanben.org/all/1_lastupdate_0_0_", script: "zen.js"},
        {title: "奇幻", input:  "https://www.wanben.org/all/2_lastupdate_0_0_", script: "zen.js"},
        {title: "武侠", input:  "https://www.wanben.org/all/3_lastupdate_0_0_", script: "zen.js"},
        {title: "仙侠", input:  "https://www.wanben.org/all/4_lastupdate_0_0_", script: "zen.js"},
        {title: "都市", input:  "https://www.wanben.org/all/5_lastupdate_0_0_", script: "zen.js"},
        {title: "军事", input:  "https://www.wanben.org/all/6_lastupdate_0_0_", script: "zen.js"},
        {title: "历史", input:  "https://www.wanben.org/all/7_lastupdate_0_0_", script: "zen.js"},
        {title: "游戏", input:  "https://www.wanben.org/all/8_lastupdate_0_0_", script: "zen.js"},
        {title: "竞技", input:  "https://www.wanben.org/all/9_lastupdate_0_0_", script: "zen.js"},
        {title: "科幻", input:  "https://www.wanben.org/all/10_lastupdate_0_0_", script: "zen.js"},
        {title: "悬疑", input:  "https://www.wanben.org/all/11_lastupdate_0_0_", script: "zen.js"},
        {title: "灵异", input:  "https://www.wanben.org/all/12_lastupdate_0_0_", script: "zen.js"},
        {title: "古代言情", input:  "https://www.wanben.org/all/14_lastupdate_0_0_", script: "zen.js"},
        {title: "仙侠奇缘", input:  "https://www.wanben.org/all/15_lastupdate_0_0_", script: "zen.js"},
        {title: "现代言情", input:  "https://www.wanben.org/all/16_lastupdate_0_0_", script: "zen.js"},
        {title: "浪漫青春", input:  "https://www.wanben.org/all/17_lastupdate_0_0_", script: "zen.js"},
        {title: "玄幻言情", input:  "https://www.wanben.org/all/18_lastupdate_0_0_", script: "zen.js"},
        {title: "悬疑灵异", input:  "https://www.wanben.org/all/19_lastupdate_0_0_", script: "zen.js"},
        {title: "科幻空间", input:  "https://www.wanben.org/all/20_lastupdate_0_0_", script: "zen.js"},
        {title: "游戏竞技", input:  "https://www.wanben.org/all/21_lastupdate_0_0_", script: "zen.js"},
        {title: "BL文", input:  "https://www.wanben.org/all/22_lastupdate_0_0_", script: "zen.js"},
        {title: "GL文", input:  "https://www.wanben.org/all/23_lastupdate_0_0_", script: "zen.js"},
        {title: "二次元", input:  "https://www.wanben.org/all/24_lastupdate_0_0_", script: "zen.js"},
        {title: "其他", input:  "https://www.wanben.org/all/13_lastupdate_0_0_", script: "zen.js"}
    ]);
}