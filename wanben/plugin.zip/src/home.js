function execute() {
    return Response.success([
        {title: "最新更新列表", input: "http://www.wanben.org/", script: "gen.js"}

    ]);
}