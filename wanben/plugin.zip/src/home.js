function execute() {
    return Response.success([
        {title: "最近更新", input:  "https://www.wanben.org/all/0_lastupdate_0_0_", script: "gen.js"}
    ]);
}