function execute() {
    return Response.success([
        {title: "玄幻奇幻", input:  "https://www.netxsw.com/books/list-t-3.html", script: "zen.js"},
        {title: "武侠修真", input:  "https://www.netxsw.com/books/list-t-8.html", script: "zen.js"},
        {title: "都市小说", input:  "https://www.netxsw.com/books/list-t-21.html", script: "zen.js"},
        {title: "恐怖灵异", input:  "https://www.netxsw.com/books/list-t-4.html", script: "zen.js"},
        {title: "乡村生活", input:  "https://www.netxsw.com/books/list-t-9.html", script: "zen.js"},
        {title: "都市言情", input:  "https://www.netxsw.com/books/list-t-5.html", script: "zen.js"},
        {title: "古代言情", input:  "https://www.netxsw.com/books/list-t-6.html", script: "zen.js"},
        {title: "科幻末世", input:  "https://www.netxsw.com/books/list-t-12.html", script: "zen.js"},
        {title: "历史军事", input:  "https://www.netxsw.com/books/list-t-11.html", script: "zen.js"},
        {title: "穿越小说", input:  "https://www.netxsw.com/books/list-t-10.html", script: "zen.js"},
        {title: "浪漫青春", input:  "https://www.netxsw.com/books/list-t-7.html", script: "zen.js"},
        {title: "侦探推理", input:  "https://www.netxsw.com/books/list-t-23.html", script: "zen.js"},
        {title: "游戏竞技", input:  "https://www.netxsw.com/books/list-t-16.html", script: "zen.js"},
        {title: "现代文学", input:  "https://www.netxsw.com/books/list-t-14.html", script: "zen.js"}
    ]);
}