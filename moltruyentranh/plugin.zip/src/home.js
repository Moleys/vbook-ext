function execute() {
    return Response.success([
        {title: "Cập nhật", input: "0", script: "gen.js"},
    ]);
}