function execute() {
    return Response.success([
        {title: "首页", input: "https://www.biqugeabc.com/", script: "gen.js"},
        {title: "玄幻奇幻", input: "https://www.biqugeabc.com/lists/1.html", script: "gen.js"},
        {title: "武侠仙侠", input: "https://www.biqugeabc.com/lists/2.html", script: "gen.js"},
        {title: "都市言情", input: "https://www.biqugeabc.com/lists/3.html", script: "gen.js"},
        {title: "历史军事", input: "https://www.biqugeabc.com/lists/4.html", script: "gen.js"},
        {title: "科幻灵异", input: "https://www.biqugeabc.com/lists/5.html", script: "gen.js"},
        {title: "网游竞技", input: "https://www.biqugeabc.com/lists/6.html", script: "gen.js"},
        {title: "女生频道", input: "https://www.biqugeabc.com/lists/7.html", script: "gen.js"}

    ]);
}