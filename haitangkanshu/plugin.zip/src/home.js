function execute() {
    return Response.success([
        {title: "全部", input:  "https://www.haitangkanshu.com/category/0/", script: "gen.js"}

    ]);
}