function execute() {
    return Response.success([
        {title: "玄幻", input:  "http://www.qiuxiaoshuo.com/xuanhuanxiaoshuo/", script: "gen.js"},
        {title: "奇幻", input:  "http://www.qiuxiaoshuo.com/qihuanxiaoshuo/", script: "gen.js"},
        {title: "修真", input:  "http://www.qiuxiaoshuo.com/xiuzhenxiaoshuo/", script: "gen.js"},
        {title: "都市", input:  "http://www.qiuxiaoshuo.com/dushixiaoshuo/", script: "gen.js"},
        {title: "言情", input:  "http://www.qiuxiaoshuo.com/yanqingxiaoshuo/", script: "gen.js"},
        {title: "历史", input:  "http://www.qiuxiaoshuo.com/lishixiaoshuo/", script: "gen.js"},
        {title: "耽美", input:  "http://www.qiuxiaoshuo.com/danmeixiaoshuo/", script: "gen.js"},
        {title: "武侠", input:  "http://www.qiuxiaoshuo.com/wuxiaxiaoshuo/", script: "gen.js"},
        {title: "科幻", input:  "http://www.qiuxiaoshuo.com/kehuanxiaoshuo/", script: "gen.js"},
        {title: "游戏", input:  "http://www.qiuxiaoshuo.com/youxixiaoshuo/", script: "gen.js"},
        {title: "军事", input:  "http://www.qiuxiaoshuo.com/junshixiaoshuo/", script: "gen.js"},
        {title: "竞技", input:  "http://www.qiuxiaoshuo.com/jingjixiaoshuo/", script: "gen.js"},
        {title: "灵异", input:  "http://www.qiuxiaoshuo.com/lingyixiaoshuo/", script: "gen.js"},
        {title: "商战", input:  "http://www.qiuxiaoshuo.com/shangzhanxiaoshuo/", script: "gen.js"},
        {title: "校园", input:  "http://www.qiuxiaoshuo.com/xiaoyuanxiaoshuo/", script: "gen.js"},
        {title: "官场", input:  "http://www.qiuxiaoshuo.com/guanchangxiaoshuo/", script: "gen.js"},
        {title: "职场", input:  "http://www.qiuxiaoshuo.com/zhichangxiaoshuo/", script: "gen.js"},
        {title: "其他", input:  "http://www.qiuxiaoshuo.com/qitaxiaoshuo/", script: "gen.js"}

    ]);
}