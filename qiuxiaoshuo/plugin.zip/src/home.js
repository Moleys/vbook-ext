function execute() {
    return Response.success([
        {title: "玄幻", input:  "http://www.qiuxiaoshuo.org/xuanhuanxiaoshuo/", script: "gen.js"},
        {title: "奇幻", input:  "http://www.qiuxiaoshuo.org/qihuanxiaoshuo/", script: "gen.js"},
        {title: "修真", input:  "http://www.qiuxiaoshuo.org/xiuzhenxiaoshuo/", script: "gen.js"},
        {title: "都市", input:  "http://www.qiuxiaoshuo.org/dushixiaoshuo/", script: "gen.js"},
        {title: "言情", input:  "http://www.qiuxiaoshuo.org/yanqingxiaoshuo/", script: "gen.js"},
        {title: "历史", input:  "http://www.qiuxiaoshuo.org/lishixiaoshuo/", script: "gen.js"},
        {title: "耽美", input:  "http://www.qiuxiaoshuo.org/danmeixiaoshuo/", script: "gen.js"},
        {title: "武侠", input:  "http://www.qiuxiaoshuo.org/wuxiaxiaoshuo/", script: "gen.js"},
        {title: "科幻", input:  "http://www.qiuxiaoshuo.org/kehuanxiaoshuo/", script: "gen.js"},
        {title: "游戏", input:  "http://www.qiuxiaoshuo.org/youxixiaoshuo/", script: "gen.js"},
        {title: "军事", input:  "http://www.qiuxiaoshuo.org/junshixiaoshuo/", script: "gen.js"},
        {title: "竞技", input:  "http://www.qiuxiaoshuo.org/jingjixiaoshuo/", script: "gen.js"},
        {title: "灵异", input:  "http://www.qiuxiaoshuo.org/lingyixiaoshuo/", script: "gen.js"},
        {title: "商战", input:  "http://www.qiuxiaoshuo.org/shangzhanxiaoshuo/", script: "gen.js"},
        {title: "校园", input:  "http://www.qiuxiaoshuo.org/xiaoyuanxiaoshuo/", script: "gen.js"},
        {title: "官场", input:  "http://www.qiuxiaoshuo.org/guanchangxiaoshuo/", script: "gen.js"},
        {title: "职场", input:  "http://www.qiuxiaoshuo.org/zhichangxiaoshuo/", script: "gen.js"},
        {title: "其他", input:  "http://www.qiuxiaoshuo.org/qitaxiaoshuo/", script: "gen.js"}

    ]);
}