function execute() {
    return Response.success([
        {title: "玄幻", input:  "/xuanhuanxiaoshuo/", script: "gen.js"},
        {title: "奇幻", input:  "/qihuanxiaoshuo/", script: "gen.js"},
        {title: "修真", input:  "/xiuzhenxiaoshuo/", script: "gen.js"},
        {title: "都市", input:  "/dushixiaoshuo/", script: "gen.js"},
        {title: "言情", input:  "/yanqingxiaoshuo/", script: "gen.js"},
        {title: "历史", input:  "/lishixiaoshuo/", script: "gen.js"},
        {title: "耽美", input:  "/danmeixiaoshuo/", script: "gen.js"},
        {title: "武侠", input:  "/wuxiaxiaoshuo/", script: "gen.js"},
        {title: "科幻", input:  "/kehuanxiaoshuo/", script: "gen.js"},
        {title: "游戏", input:  "/youxixiaoshuo/", script: "gen.js"},
        {title: "军事", input:  "/junshixiaoshuo/", script: "gen.js"},
        {title: "竞技", input:  "/jingjixiaoshuo/", script: "gen.js"},
        {title: "灵异", input:  "/lingyixiaoshuo/", script: "gen.js"},
        {title: "商战", input:  "/shangzhanxiaoshuo/", script: "gen.js"},
        {title: "校园", input:  "/xiaoyuanxiaoshuo/", script: "gen.js"},
        {title: "官场", input:  "/guanchangxiaoshuo/", script: "gen.js"},
        {title: "职场", input:  "/zhichangxiaoshuo/", script: "gen.js"},
        {title: "其他", input:  "/qitaxiaoshuo/", script: "gen.js"}

    ]);
}