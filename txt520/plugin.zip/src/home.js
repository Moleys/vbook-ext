function execute() {
    return Response.success([
        {title: "最新", input:  "http://www.txt520.com/latest/", script: "gen.js"}

    ]);
}