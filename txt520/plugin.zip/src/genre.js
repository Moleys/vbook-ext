function execute() {
    return Response.success([
        {title: "玄幻", input:  "http://www.txt520.com/xuanhuan/", script: "gen.js"},
        {title: "修真", input:  "http://www.txt520.com/xiuzhen/", script: "gen.js"},
        {title: "都市", input:  "http://www.txt520.com/ds/", script: "gen.js"},
        {title: "言情", input:  "http://www.txt520.com/yq/", script: "gen.js"},
        {title: "网游", input:  "http://www.txt520.com/wangyou/", script: "gen.js"},
        {title: "科幻", input:  "http://www.txt520.com/kehuan/", script: "gen.js"},
        {title: "穿越", input:  "http://www.txt520.com/chuanyue/", script: "gen.js"},
        {title: "武侠", input:  "http://www.txt520.com/wuxia/", script: "gen.js"},
        {title: "历史", input:  "http://www.txt520.com/lishi/", script: "gen.js"},
        {title: "军事", input:  "http://www.txt520.com/junshi/", script: "gen.js"},
        {title: "乡土", input:  "http://www.txt520.com/xt/", script: "gen.js"},
        {title: "官场", input:  "http://www.txt520.com/guanchang/", script: "gen.js"},
        {title: "奇幻", input:  "http://www.txt520.com/qihuan/", script: "gen.js"},
        {title: "鬼话", input:  "http://www.txt520.com/guihua/", script: "gen.js"},
        {title: "耽美", input:  "http://www.txt520.com/danmei/", script: "gen.js"},
        {title: "同人", input:  "http://www.txt520.com/erciyuan/", script: "gen.js"},
        {title: "精品", input:  "http://www.txt520.com/xiaoshuo/", script: "gen.js"},
        {title: "传记", input:  "http://www.txt520.com/zhuanji/", script: "gen.js"},
        {title: "名著", input:  "http://www.txt520.com/mingzhu/", script: "gen.js"},
        {title: "排行", input:  "http://www.txt520.com/ranking/", script: "gen.js"}

    ]);
}